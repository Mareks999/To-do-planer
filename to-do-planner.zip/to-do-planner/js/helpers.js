const PRIORITY = { Low: 1, Medium: 2, High: 3 };
const HASH_ITERATIONS = 150000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

let uid;
let account;
let unsubscribers = [];
const userNames = {};

const state = {
  me: [],
  all: [],
  projects: [],
  invites: [],
  view: "me",
  tab: "active",
  sort: "due",
  priority: "all",
  due: "all",
  query: "",
  editId: null,
};

const $ = (selector) => document.querySelector(selector);

const escapeHtml = (text) => String(text ?? "").replace(/[&<>"']/g, (ch) => "&#" + ch.charCodeAt(0) + ";");

const showError = (form, text) => {
  form.querySelector(".er").textContent = text || "";
};

const showMessage = (text) => {
  $("#msg").textContent = text || "";
  $("#pmsg").textContent = text || "";
};
const showSaveError = () => showMessage("Neizdevās saglabāt izmaiņas. Pārbaudi tiesības un mēģini vēlreiz.");

const encoder = new TextEncoder();
const toHex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
const fromHex = (hex) => Uint8Array.from(hex.match(/../g), (pair) => parseInt(pair, 16));
const randomBytes = (count) => crypto.getRandomValues(new Uint8Array(count));
const sha256 = async (text) => toHex(await crypto.subtle.digest("SHA-256", encoder.encode(text)));

const newId = (prefix = "") => prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

async function hashPassword(password, salt, iterations) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  return toHex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, key, 256));
}

function passwordError(password, repeat) {
  if (password.length < 8) return "Parolei jābūt vismaz 8 rakstzīmēm.";
  if (password.length > 100) return "Parole ir pārāk gara.";
  if (!/\p{L}/u.test(password) || !/\d/.test(password)) return "Parolei jāsatur burts un cipars.";
  return password === repeat ? "" : "Paroles nesakrīt.";
}

const nameError = (name) => (name.length < 2 || name.length > 50 ? "Vārdam jābūt 2 līdz 50 rakstzīmēm." : "");

const readEmail = (form) => form.e.value.trim().toLowerCase();

const formatDate = (iso) => (iso ? iso.split("-").reverse().join(".") : "");
const compareDue = (a, b) => (a.due || "9999").localeCompare(b.due || "9999");
const nameOf = (id) => (id === uid ? "Es" : userNames[id] || "Lietotājs");

function avatar(id) {
  const name = nameOf(id);
  return `<span class="av" title="${escapeHtml(name)}">${escapeHtml(name[0].toUpperCase())}</span>`;
}
