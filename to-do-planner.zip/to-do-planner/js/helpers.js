/* helpers.js: globālie mainīgie un sīkas funkcijas, ko izmanto visi pārējie faili. */

/* ---------- Konstantes ---------- */

const PRIORITY = { Low: 1, Medium: 2, High: 3 }; // lielāks skaitlis = svarīgāks uzdevums
const HASH_ITERATIONS = 150000; // cik reižu PBKDF2 atkārto hashēšanu (lēnāk = grūtāk uzminēt paroli)
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/* ---------- Globālais stāvoklis ---------- */

let uid; // ielogotā lietotāja id
let account; // ielogotā lietotāja konts: { name, email, salt, hash, it }
let unsubscribers = []; // funkcijas, kas aptur datu klausīšanos (izrakstoties)
const userNames = {}; // lietotāja id -> vārds

// Viss, ko redzam ekrānā, tiek zīmēts no šī objekta (skat. draw() failā render.js).
const state = {
  me: [], // mani personīgie uzdevumi
  all: [], // visi projekti datubāzē
  projects: [], // tikai projekti, kuros esmu dalībnieks
  invites: [], // uzaicinājumi man, kas gaida atbildi
  view: "me", // "me", "projects", "user" vai projekta id
  tab: "active", // "active" vai "done"
  sort: "due", // "due", "prio" vai "name"
  priority: "all", // prioritātes filtrs
  due: "all", // termiņa filtrs: "all", "today", "week", "late"
  query: "", // meklēšanas teksts
  editId: null, // uzdevuma id, ko šobrīd labojam (null = veidojam jaunu)
};

/* ---------- DOM un teksts ---------- */

const $ = (selector) => document.querySelector(selector);

// Aizvieto HTML simbolus, lai lietotāja teksts nekad netiktu izpildīts kā kods (XSS aizsardzība).
const escapeHtml = (text) => String(text ?? "").replace(/[&<>"']/g, (ch) => "&#" + ch.charCodeAt(0) + ";");

// Parāda kļūdu formas sarakstītajā <p class="er"> elementā (tukšs teksts to notīra).
const showError = (form, text) => {
  form.querySelector(".er").textContent = text || "";
};

// Īsa ziņa uzdevumu un projektu lapā.
const showMessage = (text) => {
  $("#msg").textContent = text || "";
  $("#pmsg").textContent = text || "";
};
const showSaveError = () => showMessage("Neizdevās saglabāt izmaiņas. Pārbaudi tiesības un mēģini vēlreiz.");

/* ---------- Šifrēšana (Web Crypto) ---------- */

const encoder = new TextEncoder();
const toHex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
const fromHex = (hex) => Uint8Array.from(hex.match(/../g), (pair) => parseInt(pair, 16));
const randomBytes = (count) => crypto.getRandomValues(new Uint8Array(count));
const sha256 = async (text) => toHex(await crypto.subtle.digest("SHA-256", encoder.encode(text)));

// Unikāls id: laiks + nejauši burti, ar nepieciešamo prefiksu ("u" lietotājam, "t" uzdevumam).
const newId = (prefix = "") => prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

// PBKDF2: no paroles un "sāls" izveido hash, no kura paroli atgūt nevar.
async function hashPassword(password, salt, iterations) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  return toHex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt, iterations }, key, 256));
}

/* ---------- Validācija (atgriež kļūdas tekstu vai "") ---------- */

function passwordError(password, repeat) {
  if (password.length < 8) return "Parolei jābūt vismaz 8 rakstzīmēm.";
  if (password.length > 100) return "Parole ir pārāk gara.";
  if (!/\p{L}/u.test(password) || !/\d/.test(password)) return "Parolei jāsatur burts un cipars.";
  return password === repeat ? "" : "Paroles nesakrīt.";
}

const nameError = (name) => (name.length < 2 || name.length > 50 ? "Vārdam jābūt 2 līdz 50 rakstzīmēm." : "");

// Formas e-pasta lauks (name="e"), notīrīts un ar mazajiem burtiem.
const readEmail = (form) => form.e.value.trim().toLowerCase();

/* ---------- Datumi un vārdi ---------- */

const formatDate = (iso) => (iso ? iso.split("-").reverse().join(".") : ""); // 2026-10-19 -> 19.10.2026
const compareDue = (a, b) => (a.due || "9999").localeCompare(b.due || "9999"); // uzdevumi bez termiņa - beigās
const nameOf = (id) => (id === uid ? "Es" : userNames[id] || "Lietotājs");

// Aplis ar vārda pirmo burtu.
function avatar(id) {
  const name = nameOf(id);
  return `<span class="av" title="${escapeHtml(name)}">${escapeHtml(name[0].toUpperCase())}</span>`;
}
