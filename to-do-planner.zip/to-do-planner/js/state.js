function getContext() {
  if (state.view === "me") {
    return {
      items: state.me,
      save: (items) => db.doc(`data/users/${uid}/tasks`).set({ items }),
      members: [uid],
      isOwner: true,
      title: "Mani uzdevumi",
    };
  }

  const project = state.projects.find((p) => p.id === state.view);
  if (!project) {

    return { items: [], save: () => Promise.reject(), members: [], isOwner: false, title: "Ielādē…" };
  }
  return {
    project,
    items: project.tasks || [],
    save: (tasks) => db.doc(`projects/${project.id}`).update({ tasks }),
    members: project.members || [],
    isOwner: project.owner === uid,
    title: project.name,
  };
}

const changeTasks = (change) => {
  const ctx = getContext();
  return ctx.save(change(ctx.items));
};

const updateTask = (id, patch) =>
  changeTasks((items) => items.map((task) => (task.id === id ? { ...task, ...patch } : task)));

const canEdit = (ctx, task) => ctx.isOwner || task.by === uid || task.assignee === uid;
