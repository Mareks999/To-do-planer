/* state.js: nosaka, ar kādu uzdevumu sarakstu šobrīd strādājam (mani uzdevumi vai atvērtais projekts). */

// Atgriež "kontekstu":
//   items    - uzdevumu saraksts, ko rādām
//   save     - funkcija, kas saglabā jauno sarakstu datubāzē
//   members  - kas drīkst būt uzdevuma izpildītājs
//   isOwner  - vai lietotājs drīkst visu (personīgajos uzdevumos vienmēr jā)
//   project  - projekta dati (tikai projekta skatā)
function getContext() {
  if (state.view === "me") {
    return {
      items: state.me,
      save: (items) => db.doc(`data/users/${uid}/tasks`).set({ items }),
      members: [uid],
      isOwner: true,
      title: "Mani uzdevumi",
    };
  }

  const project = state.projects.find((p) => p.id === state.view);
  if (!project) {
    // Projekts vēl nav ielādēts vai skatā ir "Projekti"/"User" lapa.
    return { items: [], save: () => Promise.reject(), members: [], isOwner: false, title: "Ielādē…" };
  }
  return {
    project,
    items: project.tasks || [],
    save: (tasks) => db.doc(`projects/${project.id}`).update({ tasks }),
    members: project.members || [],
    isOwner: project.owner === uid,
    title: project.name,
  };
}

// Pārveido uzdevumu saraksta (change saņem veco sarakstu, atgriež jauno) un saglabā to.
const changeTasks = (change) => {
  const ctx = getContext();
  return ctx.save(change(ctx.items));
};

// Maina vienu uzdevumu pēc id (piem., { done: true } vai jaunie dati no formas).
const updateTask = (id, patch) =>
  changeTasks((items) => items.map((task) => (task.id === id ? { ...task, ...patch } : task)));

// Labot vai dzēst drīkst projekta īpašnieks, uzdevuma autors vai izpildītājs.
const canEdit = (ctx, task) => ctx.isOwner || task.by === uid || task.assignee === uid;
