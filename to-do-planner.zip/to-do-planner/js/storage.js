/* storage.js: vietējā "datubāze" uz localStorage (servera nav).
   Visi dati glabājas vienā JSON objektā: { "ceļš": dokuments }, piemēram "projects/abc123".
   API ir līdzīgs Firestore: doc(...).get/set/update/delete/onSnapshot un collection(...).where/get/add/onSnapshot. */
const db = (() => {
  const KEY = "todo_planner_db";
  let data = {};
  let listeners = []; // funkcijas, ko izsaucam pēc katras izmaiņas (tās pārzīmē ekrānu)

  const clone = (x) => JSON.parse(JSON.stringify(x)); // atdodam kopijas, lai kods nemainītu datus netīšām
  const notify = () => listeners.forEach((run) => run());

  function load(text) {
    try {
      data = JSON.parse(text || "{}");
    } catch {
      data = {};
    }
  }

  function save() {
    localStorage.setItem(KEY, JSON.stringify(data));
    notify();
  }

  // Reģistrē klausītāju, izsauc to uzreiz un atgriež funkciju, kas klausīšanos beidz.
  function listen(run) {
    listeners.push(run);
    run();
    return () => {
      listeners = listeners.filter((x) => x !== run);
    };
  }

  // Vai ceļš ir tieši kolekcijas dokuments ("projects/x" ir kolekcijā "projects", "projects/x/y" nav).
  const inCollection = (col, path) => path.startsWith(col + "/") && !path.slice(col.length + 1).includes("/");

  const docSnap = (path) => ({
    id: path.split("/").pop(),
    exists: data[path] !== undefined,
    data: () => (data[path] === undefined ? undefined : clone(data[path])),
  });

  const querySnap = (col, filter) => ({
    docs: Object.keys(data)
      .filter((path) => inCollection(col, path) && (!filter || filter(data[path])))
      .map(docSnap),
  });

  function doc(path) {
    return {
      get: async () => docSnap(path),
      set: async (obj) => {
        data[path] = clone(obj);
        save();
      },
      update: async (patch) => {
        if (!data[path]) throw new Error("Dokuments nav atrasts: " + path);
        data[path] = { ...data[path], ...clone(patch) };
        save();
      },
      delete: async () => {
        delete data[path];
        save();
      },
      onSnapshot: (callback) => listen(() => callback(docSnap(path))),
    };
  }

  function collection(col, filter) {
    return {
      where: (field, op, value) => collection(col, (d) => d[field] === value), // atbalstām tikai ==
      get: async () => querySnap(col, filter),
      add: async (obj) => {
        const id = newId();
        data[col + "/" + id] = clone(obj);
        save();
        return { id };
      },
      onSnapshot: (callback) => listen(() => callback(querySnap(col, filter))),
    };
  }

  load(localStorage.getItem(KEY));

  // Izmaiņas citā cilnē (tas pats pārlūks) parādās uzreiz.
  window.addEventListener("storage", (e) => {
    if (e.key === KEY) {
      load(e.newValue);
      notify();
    }
  });

  return { doc, collection };
})();
