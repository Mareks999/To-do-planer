/* actions.js: kas notiek, kad lietotājs ko nospiež vai ievada.
   Pogām HTML ir atribūts data-action="vārds" (un dažreiz data-id="..."), tāpēc visi klikšķi nonāk vienā vietā:
   saraksts `actions` zemāk. Katra funkcija saņem (id, poga, konteksts). */

function resetTaskForm() {
  state.editId = null;
  const form = $("#f");
  form.reset();
  showError(form);
}

function taskError(form, ctx) {
  const title = form.ti.value.trim();
  if (!title) return "Ievadi uzdevuma nosaukumu.";
  if (title.length > 100) return "Nosaukums drīkst būt līdz 100 rakstzīmēm.";
  if (form.ds.value.trim().length > 500) return "Apraksts drīkst būt līdz 500 rakstzīmēm.";
  if (!PRIORITY[form.pr.value]) return "Izvēlies prioritāti.";
  if (form.du.value && !/^\d{4}-\d{2}-\d{2}$/.test(form.du.value)) return "Termiņš nav derīgs.";
  if (form.as.value && !ctx.members.includes(form.as.value)) return "Izvēlētais dalībnieks nav pieejams.";
  return "";
}

function setTheme(theme) {
  try {
    localStorage.setItem("pl_theme", theme);
  } catch {}
  document.documentElement.dataset.theme = theme;
  draw();
}

/* ---------- Pogu darbības ---------- */

const actions = {
  // Navigācija un dialogi
  authTab: (id) => showAuthTab(id),
  go: (id) => {
    state.view = id;
    resetTaskForm();
    $("#imsg").textContent = "";
    showMessage();
    draw();
  },
  tab: (id) => {
    state.tab = id;
    draw();
  },
  newTask: () => {
    resetTaskForm();
    $("#dt").textContent = "Jauns uzdevums";
    $("#dlg").showModal();
  },
  close: (id, button) => button.closest("dialog").close(),
  changePassword: () => {
    const form = $("#fpw");
    form.reset();
    showError(form);
    $("#pwd").showModal();
  },
  editName: () => {
    const form = $("#fnm");
    form.n.value = account.name;
    showError(form);
    $("#nmd").showModal();
  },
  theme: (id) => setTheme(id),
  logout: () => logout(),

  // Uzdevumi
  editTask: (id, button, ctx) => {
    const task = ctx.items.find((t) => t.id === id);
    if (!task || !canEdit(ctx, task)) return;

    const form = $("#f");
    state.editId = id;
    form.ti.value = task.title || "";
    form.ds.value = task.desc || "";
    form.du.value = task.due || "";
    form.pr.value = task.prio;
    form.as.value = task.assignee || "";
    showError(form);
    $("#dt").textContent = "Labot uzdevumu";
    $("#dlg").showModal();
  },
  deleteTask: async (id, button, ctx) => {
    const task = ctx.items.find((t) => t.id === id);
    if (task && canEdit(ctx, task) && confirm("Dzēst šo uzdevumu?")) {
      await changeTasks((items) => items.filter((t) => t.id !== id));
    }
  },
  clearDone: async (id, button, ctx) => {
    if (ctx.isOwner && confirm("Dzēst visus pabeigtos uzdevumus?")) {
      await changeTasks((items) => items.filter((t) => !t.done));
    }
  },

  // Projekti un uzaicinājumi
  removeMember: async (id, button, ctx) => {
    // Poga "Pamest projektu" nav data-id, tāpēc tad noņemam pašu lietotāju.
    const memberId = id || uid;
    const leaving = memberId === uid;
    const allowed = ctx.project && (ctx.isOwner ? memberId !== ctx.project.owner : leaving);
    if (!allowed || !confirm(leaving ? "Pamest šo projektu?" : "Noņemt dalībnieku no projekta?")) return;

    await db.doc(`projects/${ctx.project.id}`).update({
      members: ctx.members.filter((m) => m !== memberId),
      // Noņemtā dalībnieka uzdevumi paliek, bet kļūst "nav piešķirti".
      tasks: ctx.items.map((t) => (t.assignee === memberId ? { ...t, assignee: "" } : t)),
    });
    if (leaving) {
      state.view = "me";
      draw();
    }
  },
  deleteProject: async (id, button, ctx) => {
    if (ctx.project && ctx.isOwner && confirm("Dzēst visu projektu un tā uzdevumus?")) {
      await db.doc(`projects/${ctx.project.id}`).delete();
      state.view = "me";
      draw();
    }
  },
  accept: async (id) => {
    const invite = state.invites.find((i) => i.id === id);
    if (!invite) return;
    const project = state.all.find((p) => p.id === invite.pid);
    if (project && !(project.members || []).includes(uid)) {
      await db.doc(`projects/${project.id}`).update({ members: [...(project.members || []), uid] });
    }
    await db.doc("invites/" + id).update({ status: "accepted" });
  },
  decline: (id) => db.doc("invites/" + id).update({ status: "declined" }),
};

// Visi klikšķi uz elementiem ar data-action nonāk šeit.
document.addEventListener("click", async (e) => {
  const button = e.target.closest("[data-action]");
  const handler = button && actions[button.dataset.action]; // "toggle" šeit nav - to apstrādā "change" notikums
  if (!handler) return;

  try {
    await handler(button.dataset.id, button, getContext());
  } catch {
    showSaveError();
  }
});

/* ---------- Formas ---------- */

// Jauns vai labots uzdevums.
$("#f").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const error = taskError(form, getContext());
  showError(form, error);
  if (error) return;

  const data = {
    title: form.ti.value.trim(),
    desc: form.ds.value.trim(),
    due: form.du.value,
    prio: form.pr.value,
    assignee: form.as.value,
  };

  try {
    if (state.editId) {
      await updateTask(state.editId, data);
    } else {
      await changeTasks((items) => [...items, { id: newId("t"), done: false, by: uid, ...data }]);
    }
    resetTaskForm();
    $("#dlg").close();
    showMessage();
  } catch {
    showError(form, "Neizdevās saglabāt. Pārbaudi tiesības un mēģini vēlreiz.");
  }
});

// Aizverot dialogu (arī ar Esc), beidzam labošanu.
$("#dlg").addEventListener("close", () => {
  state.editId = null;
});

// Jauns projekts.
$("#np").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = e.target.n.value.trim();
  if (name.length < 2 || name.length > 60) return showMessage("Projekta nosaukumam jābūt 2 līdz 60 rakstzīmēm.");

  try {
    const created = await db.collection("projects").add({ name, owner: uid, members: [uid], tasks: [] });
    e.target.reset();
    state.view = created.id; // uzreiz atveram jauno projektu
    showMessage();
    draw();
  } catch {
    showSaveError();
  }
});

// Uzaicinājums projektam pēc e-pasta (tikai īpašniekam).
$("#fi").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const ctx = getContext();
  const email = readEmail(form);
  const say = (text) => ($("#imsg").textContent = text);

  if (!ctx.project || !ctx.isOwner) return;
  if (!EMAIL_RE.test(email)) return say("Ievadi derīgu e-pasta adresi.");

  try {
    const found = await db.doc("emails/" + (await sha256(email))).get();
    if (!found.exists) return say("Lietotājs ar šādu e-pastu nav reģistrēts.");

    const userId = found.data().uid;
    if (ctx.members.includes(userId)) return say("Šis lietotājs jau ir dalībnieks.");

    const invitesForUser = await db.collection("invites").where("to", "==", userId).get();
    const alreadyInvited = invitesForUser.docs.some(
      (d) => d.data().pid === ctx.project.id && d.data().status === "pending",
    );
    if (alreadyInvited) return say("Šis lietotājs jau ir uzaicināts.");

    await db.collection("invites").add({
      pid: ctx.project.id,
      pname: ctx.project.name,
      to: userId,
      from: uid,
      status: "pending",
    });
    form.reset();
    say("Uzaicinājums nosūtīts.");
  } catch {
    say("Neizdevās nosūtīt uzaicinājumu.");
  }
});

// Vārda maiņa.
$("#fnm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const name = form.n.value.trim();
  const error = nameError(name);
  if (error) return showError(form, error);

  try {
    const updated = { ...account, name };
    await db.doc(`data/users/${uid}/account`).set(updated);
    await db.doc(`users/${uid}`).set({ name });
    account = updated;
    $("#nmd").close();
    draw();
  } catch {
    showError(form, "Neizdevās saglabāt vārdu.");
  }
});

/* ---------- Filtri, kārtošana, meklēšana un "pabeigts" ķeksītis ---------- */

// Kura izvēlne (id) maina kuru state lauku.
const FILTER_FIELDS = { so: "sort", fl: "priority", dz: "due" };

document.addEventListener("change", async (e) => {
  const target = e.target;

  if (FILTER_FIELDS[target.id]) {
    state[FILTER_FIELDS[target.id]] = target.value;
    draw();
  } else if (target.dataset.action === "toggle") {
    try {
      await updateTask(target.dataset.id, { done: target.checked });
      showMessage();
    } catch {
      showSaveError();
    }
  }
});

document.addEventListener("input", (e) => {
  if (e.target.id === "sq") {
    state.query = e.target.value.trim();
    draw();
  }
});
