/* app.js: lietotnes starts. Ja šajā cilnē jau ir pieteicies lietotājs, sesiju atjauno; citādi rāda pieslēgšanos. */
(async () => {
  // Bez Web Crypto (piem., http ārpus localhost) paroles nevar šifrēt.
  if (!window.crypto?.subtle) {
    $("#auth").hidden = false;
    showAuthTab("in");
    showError($("#fin"), "Šis pārlūks neatbalsta šifrēšanu. Atver lapu ar https vai localhost.");
    return;
  }

  let token = null;
  try {
    token = sessionStorage.getItem("pl");
  } catch {}

  if (token) {
    const session = await db.doc("sessions/" + token).get();
    const userId = session.exists ? session.data().uid : null;
    const accountDoc = userId ? await db.doc(`data/users/${userId}/account`).get() : null;
    if (accountDoc?.exists) {
      uid = userId;
      account = accountDoc.data();
      startSession(token);
      return;
    }
  }

  // Ja datubāzē vēl nav neviena lietotāja, uzreiz rādām reģistrāciju.
  $("#auth").hidden = false;
  const users = await db.collection("users").get();
  showAuthTab(users.docs.length ? "in" : "up");
})();
