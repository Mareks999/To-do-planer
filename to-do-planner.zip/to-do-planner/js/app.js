/* app.js: lietotnes starts. Ja šajā cilnē jau ir pieteicies lietotājs, sesiju atjauno. */
(async () => {
  if (!window.crypto || !crypto.subtle) {
    $("#auth").hidden = false;
    setTab("in");
    er($("#fin"), "Šis pārlūks neatbalsta šifrēšanu. Atver lapu ar https vai localhost.");
    return;
  }
  let id = null;
  try {
    id = sessionStorage.getItem("pl");
  } catch {}
  if (id) {
    const s = await db.doc("data/users/" + id + "/account").get();
    if (s.exists) {
      uid = id;
      ACC = s.data();
      enter();
      return;
    }
  }
  $("#auth").hidden = false;
  const users = await db.collection("users").get();
  setTab(users.docs.length ? "in" : "up");
})();
