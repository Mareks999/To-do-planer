/* Interfeisa zīmēšana: sānjosla, progresa josla, filtri un uzdevumu saraksts. */
function draw() {
  const c = ctx(),
    L0 = Date.now() - new Date().getTimezoneOffset() * 6e4,
    T = new Date(L0).toISOString().slice(0, 10),
    wk = new Date(L0 + 6048e5).toISOString().slice(0, 10);
  $("#ttl").textContent = c.title;
  $("#nav").innerHTML =
    '<button data-a="go" data-id="me" class="' +
    (S.view === "me" ? "on" : "") +
    '">Mani uzdevumi</button><h3>Projekti</h3>' +
    (S.proj
      .map(
        (p) =>
          `<button data-a="go" data-id="${E(p.id)}" class="${S.view === p.id ? "on" : ""}">${E(p.name)}</button>`,
      )
      .join("") || "<small>Projektu vēl nav.</small>") +
    (S.inv.length
      ? "<h3>Uzaicinājumi</h3>" +
        S.inv
          .map(
            (i) =>
              `<div class="inv">${E(names[i.from] || "Kāds")} uzaicina tevi projektā <b>${E(i.pname)}</b><div><button data-a="acc" data-id="${E(i.id)}">Pieņemt</button> <button data-a="rej" data-id="${E(i.id)}">Noraidīt</button></div></div>`,
          )
          .join("")
      : "");
  const all = c.items,
    dn = all.filter((t) => t.done).length,
    pc = all.length ? Math.round((100 * dn) / all.length) : 0,
    lt = all.filter((t) => !t.done && t.due && t.due < T).length;
  $("#pgb").style.width = pc + "%";
  $("#sub").textContent = all.length
    ? `${dn} no ${all.length} uzdevumiem pabeigti (${pc}%)${lt ? `, nokavēti: ${lt}` : ""}`
    : "Šeit vēl nav uzdevumu.";
  const as = $("#as"),
    v = as.value;
  $("#asw").hidden = !c.p;
  as.innerHTML =
    '<option value="">Nav piešķirts</option>' +
    c.members.map((m) => `<option value="${E(m)}">${E(nm(m))}</option>`).join("");
  as.value = v;
  $("#team").hidden = !c.p;
  if (c.p) {
    $("#mem").innerHTML = c.members
      .map(
        (m) =>
          `<li><span>${av(m)} ${E(nm(m))}${m === c.p.owner ? " (īpašnieks)" : ""}</span>${c.owner && m !== c.p.owner ? `<button data-a="rm" data-id="${E(m)}">Noņemt</button>` : ""}</li>`,
      )
      .join("");
    $("#own").hidden = !c.owner;
    $("#lv").hidden = c.owner;
    $("#dp").hidden = !c.owner;
  }
  document
    .querySelectorAll("[data-a=tab]")
    .forEach((b) => b.setAttribute("aria-pressed", b.dataset.id === S.tab));
  $("#cc").hidden = !(S.tab === "done" && dn && c.owner);
  const q = S.q.toLowerCase(),
    dz = S.dz;
  const R = all.filter(
    (t) =>
      !!t.done === (S.tab === "done") &&
      (S.fl === "all" || t.prio === S.fl) &&
      (!q || ((t.title || "") + " " + (t.desc || "")).toLowerCase().includes(q)) &&
      (dz === "all" ||
        (dz === "today"
          ? t.due === T
          : dz === "week"
            ? t.due >= T && t.due <= wk
            : !t.done && !!t.due && t.due < T)),
  );
  R.sort(
    S.sort === "prio"
      ? (a, b) => (P[b.prio] || 0) - (P[a.prio] || 0) || cd(a, b)
      : S.sort === "name"
        ? (a, b) => String(a.title).localeCompare(String(b.title), "lv")
        : (a, b) => cd(a, b) || (P[b.prio] || 0) - (P[a.prio] || 0),
  );
  $("#list").innerHTML =
    R.map((t) => {
      const m = can(c, t),
        late = !t.done && t.due && t.due < T;
      return `<li class="t ${P[t.prio] ? t.prio : ""}${t.done ? " d" : ""}"><input type="checkbox" data-a="tg" data-id="${E(t.id)}" ${t.done ? "checked" : ""} ${m ? "" : "disabled"} aria-label="Atzīmēt kā pabeigtu"><div><b>${E(t.title)}</b>${t.desc ? `<p>${E(t.desc)}</p>` : ""}<div class="m">${P[t.prio] ? `<span class="c">${E(t.prio)}</span>` : ""}${t.due ? `<span class="c ${late ? "late" : "u"}">${late ? "Nokavēts: " : "Līdz "}${E(fd(t.due))}</span>` : ""}${t.assignee ? av(t.assignee) : ""}</div></div><div class="ac">${m ? `<button class="ib" data-a="edit" data-id="${E(t.id)}" aria-label="Labot" title="Labot"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg></button><button class="ib del" data-a="del" data-id="${E(t.id)}" aria-label="Dzēst" title="Dzēst"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg></button>` : ""}</div></li>`;
    }).join("") ||
    `<li class="empty"><span class="mut">${all.length && (q || S.fl !== "all" || dz !== "all") ? "Nekas neatbilst filtriem." : S.tab === "done" ? "Pabeigto uzdevumu vēl nav." : 'Nav aktīvu uzdevumu. Nospied "Jauns uzdevums".'}</span></li>`;
}
