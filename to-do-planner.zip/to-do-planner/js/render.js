const icon = (paths) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
const ICON_EDIT = icon('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>');
const ICON_DELETE = icon(
  '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/>',
);

function taskStats(tasks) {
  const done = tasks.filter((task) => task.done).length;
  return { done, percent: tasks.length ? Math.round((100 * done) / tasks.length) : 0 };
}

const isLate = (task, today) => !task.done && !!task.due && task.due < today;

function getDates() {
  const localNow = Date.now() - new Date().getTimezoneOffset() * 60000;
  const dayFromNow = (n) => new Date(localNow + n * 86400000).toISOString().slice(0, 10);
  return { today: dayFromNow(0), tomorrow: dayFromNow(1), week: dayFromNow(7) };
}

function groupOf(task, { today, tomorrow, week }) {
  if (task.done || state.sort !== "due") return "";
  if (!task.due) return "Bez termiņa";
  if (task.due < today) return "Nokavētie";
  if (task.due === today) return "Šodien";
  if (task.due === tomorrow) return "Rīt";
  if (task.due <= week) return "Nākamās 7 dienas";
  return "Vēlāk";
}

function matchesFilters(task, { today, week }) {
  if (!!task.done !== (state.tab === "done")) return false;
  if (state.priority !== "all" && task.prio !== state.priority) return false;

  const text = `${task.title || ""} ${task.desc || ""}`.toLowerCase();
  if (state.query && !text.includes(state.query.toLowerCase())) return false;

  if (state.due === "today") return task.due === today;
  if (state.due === "week") return !!task.due && task.due >= today && task.due <= week;
  if (state.due === "late") return isLate(task, today);
  return true;
}

function sortTasks(tasks) {
  const priorityOf = (task) => PRIORITY[task.prio] || 0;
  return [...tasks].sort((a, b) => {
    if (state.sort === "prio") return priorityOf(b) - priorityOf(a) || compareDue(a, b);
    if (state.sort === "name") return String(a.title).localeCompare(String(b.title), "lv");
    return compareDue(a, b) || priorityOf(b) - priorityOf(a);
  });
}

function inviteCard(invite) {
  const id = escapeHtml(invite.id);
  const from = escapeHtml(userNames[invite.from] || "Kāds");
  return `<div class="card2 inv"><div><b>${escapeHtml(invite.pname)}</b><p class="sub">${from} uzaicina tevi pievienoties projektam</p></div><div class="acts"><button class="p" data-action="accept" data-id="${id}">Pieņemt</button><button data-action="decline" data-id="${id}">Noraidīt</button></div></div>`;
}

function projectCard(project) {
  const tasks = project.tasks || [];
  const { done, percent } = taskStats(tasks);
  return `<button class="card2 pj" data-action="go" data-id="${escapeHtml(project.id)}"><b>${escapeHtml(project.name)}</b><span class="sub">${(project.members || []).length} dalībn. · ${done} no ${tasks.length} uzdevumiem pabeigti</span><span class="pgs"><i style="width:${percent}%"></i></span></button>`;
}

function drawProjects() {

  const invites = state.invites.filter((invite) => state.all.some((p) => p.id === invite.pid));
  $("#invs").innerHTML = invites.length ? '<h3 class="gh">Uzaicinājumi</h3>' + invites.map(inviteCard).join("") : "";
  $("#pl").innerHTML =
    state.projects.map(projectCard).join("") || '<p class="sub">Projektu vēl nav. Izveido pirmo augstāk.</p>';
}

function drawUser() {
  $("#who").textContent = account.name;
  $("#wem").textContent = account.email;
  $("#wav").textContent = account.name[0].toUpperCase();
  document.querySelectorAll("[data-action=theme]").forEach((button) => {
    button.setAttribute("aria-pressed", button.dataset.id === document.documentElement.dataset.theme);
  });
}

function drawTaskHeader(ctx, today) {
  const { done, percent } = taskStats(ctx.items);
  const late = ctx.items.filter((task) => isLate(task, today)).length;

  $("#ttl").textContent = ctx.title;
  $("#bk").hidden = !ctx.project;
  $("#pgb").style.width = percent + "%";
  $("#sub").textContent = ctx.items.length
    ? `${done} no ${ctx.items.length} uzdevumiem pabeigti (${percent}%)${late ? `, nokavēti: ${late}` : ""}`
    : "Šeit vēl nav uzdevumu.";
}

function drawAssigneeSelect(ctx) {
  const select = $("#as");
  const selected = select.value;
  $("#asw").hidden = !ctx.project;
  select.innerHTML =
    '<option value="">Nav piešķirts</option>' +
    ctx.members.map((id) => `<option value="${escapeHtml(id)}">${escapeHtml(nameOf(id))}</option>`).join("");
  select.value = selected;
}

function drawTeam(ctx) {
  $("#team").hidden = !ctx.project;
  if (!ctx.project) return;

  $("#mem").innerHTML = ctx.members
    .map((id) => {
      const isProjectOwner = id === ctx.project.owner;
      const removeButton =
        ctx.isOwner && !isProjectOwner
          ? `<button data-action="removeMember" data-id="${escapeHtml(id)}">Noņemt</button>`
          : "";
      return `<li><span>${avatar(id)} ${escapeHtml(nameOf(id))}${isProjectOwner ? " (īpašnieks)" : ""}</span>${removeButton}</li>`;
    })
    .join("");

  $("#own").hidden = !ctx.isOwner;
  $("#dp").hidden = !ctx.isOwner;
  $("#lv").hidden = ctx.isOwner;
}

function taskRow(ctx, task, today) {
  const id = escapeHtml(task.id);
  const allowed = canEdit(ctx, task);
  const late = isLate(task, today);
  const dueText = task.due
    ? `<span class="${late ? "late" : ""}">${late ? "Nokavēts: " : "Līdz "}${escapeHtml(formatDate(task.due))}</span>`
    : "";
  const priorityBadge = PRIORITY[task.prio] ? `<span class="c ${task.prio}">${escapeHtml(task.prio)}</span>` : "";
  const buttons = allowed
    ? `<button class="ib" data-action="editTask" data-id="${id}" aria-label="Labot" title="Labot">${ICON_EDIT}</button><button class="ib del" data-action="deleteTask" data-id="${id}" aria-label="Dzēst" title="Dzēst">${ICON_DELETE}</button>`
    : "";

  return `<li class="t${task.done ? " d" : ""}"><input type="checkbox" data-action="toggle" data-id="${id}" ${task.done ? "checked" : ""} ${allowed ? "" : "disabled"} aria-label="Atzīmēt kā pabeigtu"><div><b>${escapeHtml(task.title)}</b>${task.desc ? `<p>${escapeHtml(task.desc)}</p>` : ""}<div class="m">${dueText}${task.assignee ? avatar(task.assignee) : ""}</div></div><div class="ac">${priorityBadge}${buttons}</div></li>`;
}

function drawTaskList(ctx, dates) {
  const visible = sortTasks(ctx.items.filter((task) => matchesFilters(task, dates)));

  const groups = new Map();
  for (const task of visible) {
    const name = groupOf(task, dates);
    groups.set(name, [...(groups.get(name) || []), task]);
  }

  const html = [...groups]
    .map(([name, tasks]) => {
      const heading = name ? `<h4 class="gh">${name}<small>${tasks.length} uzd.</small></h4>` : "";
      return `${heading}<ul>${tasks.map((task) => taskRow(ctx, task, dates.today)).join("")}</ul>`;
    })
    .join("");

  const filtering = state.query || state.priority !== "all" || state.due !== "all";
  const emptyText =
    ctx.items.length && filtering
      ? "Nekas neatbilst filtriem."
      : state.tab === "done"
        ? "Pabeigto uzdevumu vēl nav."
        : 'Nav aktīvu uzdevumu. Nospied "Jauns uzdevums".';
  $("#list").innerHTML = html || `<p class="empty">${emptyText}</p>`;
}

function draw() {
  const ctx = getContext();
  const view = state.view;
  const page = view === "projects" || view === "user" ? view : "tasks";

  $("#v-me").hidden = page !== "tasks";
  $("#v-pr").hidden = page !== "projects";
  $("#v-us").hidden = page !== "user";

  const activeNav = page === "tasks" && view !== "me" ? "projects" : view;
  document.querySelectorAll("#nav button").forEach((button) => {
    button.classList.toggle("on", button.dataset.id === activeNav);
  });

  if (page === "projects") return drawProjects();
  if (page === "user") return drawUser();

  const dates = getDates();
  drawTaskHeader(ctx, dates.today);
  drawAssigneeSelect(ctx);
  drawTeam(ctx);

  document.querySelectorAll("[data-action=tab]").forEach((button) => {
    button.setAttribute("aria-pressed", button.dataset.id === state.tab);
  });

  $("#cc").hidden = !(state.tab === "done" && taskStats(ctx.items).done && ctx.isOwner);

  drawTaskList(ctx, dates);
}
