let sessionToken;

function showAuthTab(tab) {
  $("#fin").hidden = tab !== "in";
  $("#fup").hidden = tab !== "up";
  document.querySelectorAll("[data-action=authTab]").forEach((button) => {
    button.setAttribute("aria-pressed", button.dataset.id === tab);
  });
}

async function newCredentials(password) {
  const salt = randomBytes(16);
  return { salt: toHex(salt), hash: await hashPassword(password, salt, HASH_ITERATIONS), it: HASH_ITERATIONS };
}

async function passwordMatches(acc, password) {
  return (await hashPassword(password, fromHex(acc.salt), acc.it || HASH_ITERATIONS)) === acc.hash;
}

function subscribeToData() {
  unsubscribers.forEach((stop) => stop());
  unsubscribers = [
    db.doc(`data/users/${uid}/tasks`).onSnapshot((snap) => {
      state.me = snap.exists ? snap.data().items || [] : [];
      draw();
    }),
    db.collection("users").onSnapshot((snap) => {
      snap.docs.forEach((d) => (userNames[d.id] = d.data().name));
      draw();
    }),
    db.collection("projects").onSnapshot((snap) => {
      state.all = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      state.projects = state.all.filter((p) => (p.members || []).includes(uid));
      draw();
    }),
    db.collection("invites").where("to", "==", uid).onSnapshot((snap) => {
      state.invites = snap.docs.map((d) => ({ id: d.id, ...d.data() })).filter((i) => i.status === "pending");
      draw();
    }),
  ];
}

function startSession(token) {
  if (!token) {
    token = toHex(randomBytes(24));
    db.doc("sessions/" + token).set({ uid });
  }
  sessionToken = token;
  try {
    sessionStorage.setItem("pl", token);
  } catch {}

  $("#auth").hidden = true;
  $("#app").hidden = false;
  Object.assign(state, { me: [], all: [], projects: [], invites: [], view: "me", editId: null });
  subscribeToData();
  draw();
}

function logout() {
  if (sessionToken) db.doc("sessions/" + sessionToken).delete();
  sessionToken = null;
  uid = null;
  account = null;
  try {
    sessionStorage.removeItem("pl");
  } catch {}

  unsubscribers.forEach((stop) => stop());
  unsubscribers = [];

  $("#app").hidden = true;
  $("#auth").hidden = false;
  document.querySelectorAll("#auth input").forEach((input) => (input.value = ""));
  showAuthTab("in");
}

$("#fup").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const name = form.n.value.trim();
  const email = readEmail(form);
  const emailOk = EMAIL_RE.test(email) && email.length <= 120;

  const error =
    nameError(name) || (emailOk ? "" : "Ievadi derīgu e-pasta adresi.") || passwordError(form.p.value, form.p2.value);
  showError(form, error);
  if (error) return;

  try {
    const emailDoc = db.doc("emails/" + (await sha256(email)));
    if ((await emailDoc.get()).exists) return showError(form, "Šis e-pasts jau ir reģistrēts.");

    const id = newId("u");
    const newAccount = { name, email, ...(await newCredentials(form.p.value)) };
    await emailDoc.set({ uid: id });
    await db.doc(`data/users/${id}/account`).set(newAccount);
    await db.doc(`users/${id}`).set({ name });

    uid = id;
    account = newAccount;
    form.reset();
    startSession();
  } catch {
    showError(form, "Reģistrācija neizdevās. Mēģini vēlreiz.");
  }
});

$("#fin").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const email = readEmail(form);
  if (!EMAIL_RE.test(email) || !form.p.value) return showError(form, "Ievadi e-pastu un paroli.");

  try {
    const index = await db.doc("emails/" + (await sha256(email))).get();
    const accountDoc = index.exists ? await db.doc(`data/users/${index.data().uid}/account`).get() : null;
    const found = accountDoc?.exists ? accountDoc.data() : null;

    if (!found || !(await passwordMatches(found, form.p.value))) {
      return showError(form, "Nepareizs e-pasts vai parole.");
    }

    uid = index.data().uid;
    account = found;
    showError(form);
    form.reset();
    startSession();
  } catch {
    showError(form, "Pieslēgšanās neizdevās. Mēģini vēlreiz.");
  }
});

$("#fpw").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const error = passwordError(form.p.value, form.p2.value);
  if (error) return showError(form, error);

  try {
    if (!(await passwordMatches(account, form.c.value))) return showError(form, "Pašreizējā parole nav pareiza.");

    const updated = { ...account, ...(await newCredentials(form.p.value)) };
    await db.doc(`data/users/${uid}/account`).set(updated);
    account = updated;

    form.reset();
    showError(form);
    $("#pwd").close();
    showMessage("Parole nomainīta.");
  } catch {
    showError(form, "Neizdevās nomainīt paroli.");
  }
});
