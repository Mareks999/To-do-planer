# To-Do Planner (Plānotājs)

Uzdevumu plānotājs ar lietotāju kontiem, personīgajiem uzdevumiem, dashboard un kopīgiem projektiem. Tikai HTML, CSS un JavaScript: bez servera un bez Claude.

## Kā palaist

Atver `index.html` pārlūkā (divreiz uzklikšķini uz faila). Var arī palaist ar vietējo serveri: `python -m http.server`, tad atver http://localhost:8000.

## Minimālais scenārijs

1. Cilnē "Reģistrēties" izveido pirmo kontu un pieslēdzies.
2. Izveido personīgu uzdevumu, rediģē to un atzīmē kā pabeigtu.
3. Izraksties un reģistrē otru kontu. Pieslēdzies pirmajā kontā, izveido projektu un uzaicini otru lietotāju pēc e-pasta.
4. Pieslēdzies otrajā kontā, sānjoslā pieņem uzaicinājumu un izveido uzdevumu projektā.

Padoms: vari atvērt divas cilnes, katrā citu lietotāju. Izmaiņas starp cilnēm sinhronizējas uzreiz.

## Failu struktūra

| Fails | Ko dara |
| --- | --- |
| `index.html` | lapas struktūra: pieteikšanās lapa, lietotne, dialogi |
| `css/base.css` | krāsas (gaišs un tumšs režīms), pogas, ievades lauki |
| `css/auth.css` | pieteikšanās un reģistrācijas lapa |
| `css/layout.css` | sānjosla, galvenā daļa, rīkjosla |
| `css/tasks.css` | uzdevumu saraksts, uzlīmes, avatāri, dialogi |
| `css/responsive.css` | pielāgošana telefoniem |
| `js/helpers.js` | palīgfunkcijas, hash, validācija, globālais stāvoklis |
| `js/storage.js` | datubāze uz localStorage |
| `js/state.js` | konteksts: personīgie vai projekta uzdevumi, tiesības |
| `js/render.js` | interfeisa zīmēšana (`draw`) |
| `js/auth.js` | reģistrācija, pieslēgšanās, izrakstīšanās, paroles maiņa |
| `js/actions.js` | uzdevumu, projektu un uzaicinājumu darbības |
| `js/app.js` | starts |

## Kā tiek glabāti dati

Viss atrodas pārlūka `localStorage` atslēgā `todo_planner_db`, ceļu veidā:

| Ceļš | Saturs |
| --- | --- |
| `data/users/<id>/account` | konta dati un paroles hash |
| `data/users/<id>/tasks` | lietotāja personīgie uzdevumi |
| `users/<id>` | publiskais vārds |
| `emails/<sha256>` | e-pasta unikalitātes indekss |
| `projects/<id>` | projekts: īpašnieks, dalībnieki, uzdevumi |
| `invites/<id>` | uzaicinājumi |

## Ierobežojumi

- Dati glabājas tikai šajā pārlūkā un šajā datorā. Citā pārlūkā vai datorā būs tukša lietotne, un pārlūka datu dzēšana izdzēš visu.
- Vairāki lietotāji darbojas viena pārlūka ietvaros (katram savs konts). Īstai darbībai starp dažādām ierīcēm vajadzīgs serveris (piemēram PHP un MySQL).
- Paroles tiek glabātas kā sāļots PBKDF2 hash, bet localStorage var nolasīt jebkurš, kam ir piekļuve pārlūkam. Projektu tiesības tiek kontrolētas lietotāja saskarnē.
