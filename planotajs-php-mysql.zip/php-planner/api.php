<?php
/* api.php: visa servera loģika. Paroles hashē serverī, tiesības pārbauda katrā pieprasījumā. */
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/config.php';

function out($d, $c = 200) { http_response_code($c); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function fail($m, $c = 400) { out(['error' => $m], $c); }

// Tikai POST ar JSON (citas vietnes šādu pieprasījumu nevar nosūtīt bez CORS atļaujas)
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) fail('Nederīgs pieprasījums.', 405);
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$a = $_GET['a'] ?? '';
$uid = $_SESSION['uid'] ?? null;

function q($sql, $p = []) { global $pdo; $s = $pdo->prepare($sql); $s->execute($p); return $s; }
function one($sql, $p = []) { return q($sql, $p)->fetch(); }
function str($k, $max) { global $in; return mb_substr(trim((string)($in[$k] ?? '')), 0, $max + 1); }
function pwErr($p) {
    if (mb_strlen($p) < 8) return 'Parolei jābūt vismaz 8 rakstzīmēm.';
    if (mb_strlen($p) > 100) return 'Parole ir pārāk gara.';
    if (!preg_match('/\p{L}/u', $p) || !preg_match('/\d/', $p)) return 'Parolei jāsatur burts un cipars.';
    return '';
}
function login($id) { session_regenerate_id(true); $_SESSION['uid'] = (int)$id; }
function isMember($pid, $u) { return (bool)one('SELECT 1 FROM project_members WHERE project_id=? AND user_id=?', [$pid, $u]); }
function owns($pid, $u) { return (bool)one('SELECT 1 FROM projects WHERE id=? AND owner_id=?', [$pid, $u]); }
function canTask($t, $u) {
    if (!$t) return false;
    if ($t['project_id'] === null) return (int)$t['user_id'] === $u;
    return isMember($t['project_id'], $u) && (owns($t['project_id'], $u) || (int)$t['created_by'] === $u || (int)$t['assignee_id'] === $u);
}
function T($r) {
    return ['id' => (string)$r['id'], 'title' => $r['title'], 'desc' => $r['descr'], 'due' => $r['due_date'] ?? '',
        'prio' => $r['prio'], 'done' => (bool)$r['done'], 'by' => (string)$r['created_by'], 'assignee' => (string)($r['assignee_id'] ?? '')];
}

try {
    if ($a === 'register') {
        $n = str('n', 50); $e = strtolower(str('e', 120)); $p = (string)($in['p'] ?? '');
        if (mb_strlen($n) < 2 || mb_strlen($n) > 50) fail('Vārdam jābūt 2 līdz 50 rakstzīmēm.');
        if (!filter_var($e, FILTER_VALIDATE_EMAIL) || strlen($e) > 120) fail('Ievadi derīgu e-pasta adresi.');
        if ($m = pwErr($p)) fail($m);
        if (one('SELECT 1 FROM users WHERE email=?', [$e])) fail('Šis e-pasts jau ir reģistrēts.');
        q('INSERT INTO users(name,email,pass_hash) VALUES(?,?,?)', [$n, $e, password_hash($p, PASSWORD_DEFAULT)]);
        login($GLOBALS['pdo']->lastInsertId());
        out(['ok' => true]);
    }
    if ($a === 'login') {
        $u = one('SELECT id,pass_hash FROM users WHERE email=?', [strtolower(str('e', 120))]);
        if (!$u || !password_verify((string)($in['p'] ?? ''), $u['pass_hash'])) fail('Nepareizs e-pasts vai parole.', 401);
        login($u['id']);
        out(['ok' => true]);
    }
    if (!$uid) fail('Nav pieslēgts.', 401);

    switch ($a) {
    case 'logout':
        $_SESSION = []; session_destroy(); out(['ok' => true]);

    case 'state':
        $ids = [$uid];
        $me = array_map('T', q('SELECT * FROM tasks WHERE user_id=? AND project_id IS NULL', [$uid])->fetchAll());
        $proj = [];
        foreach (q('SELECT p.* FROM projects p JOIN project_members m ON m.project_id=p.id WHERE m.user_id=? ORDER BY p.id', [$uid])->fetchAll() as $p) {
            $mem = array_map('strval', q('SELECT user_id FROM project_members WHERE project_id=?', [$p['id']])->fetchAll(PDO::FETCH_COLUMN));
            $ids = array_merge($ids, $mem);
            $proj[] = ['id' => (string)$p['id'], 'name' => $p['name'], 'owner' => (string)$p['owner_id'], 'members' => $mem,
                'tasks' => array_map('T', q('SELECT * FROM tasks WHERE project_id=?', [$p['id']])->fetchAll())];
        }
        $inv = array_map(function ($i) use (&$ids) { $ids[] = $i['from_id'];
            return ['id' => (string)$i['id'], 'pid' => (string)$i['project_id'], 'pname' => $i['name'], 'from' => (string)$i['from_id']]; },
            q("SELECT i.id,i.project_id,i.from_id,p.name FROM invites i JOIN projects p ON p.id=i.project_id WHERE i.to_id=? AND i.status='pending'", [$uid])->fetchAll());
        $ids = array_values(array_unique(array_map('intval', $ids)));
        $names = [];
        foreach (q('SELECT id,name FROM users WHERE id IN (' . implode(',', $ids) . ')')->fetchAll() as $r) $names[(string)$r['id']] = $r['name'];
        $u = one('SELECT id,name,email FROM users WHERE id=?', [$uid]);
        out(['user' => ['id' => (string)$u['id'], 'name' => $u['name'], 'email' => $u['email']], 'me' => $me, 'proj' => $proj, 'inv' => $inv, 'names' => $names]);

    case 'task_save':
        $title = str('title', 100); $desc = str('desc', 500); $due = (string)($in['due'] ?? ''); $prio = $in['prio'] ?? '';
        $pid = !empty($in['pid']) ? (int)$in['pid'] : null;
        if ($title === '') fail('Ievadi uzdevuma nosaukumu.');
        if (mb_strlen($title) > 100) fail('Nosaukums drīkst būt līdz 100 rakstzīmēm.');
        if (mb_strlen($desc) > 500) fail('Apraksts drīkst būt līdz 500 rakstzīmēm.');
        if (!in_array($prio, ['Low', 'Medium', 'High'], true)) fail('Izvēlies prioritāti.');
        if ($due !== '' && !(preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $due, $d) && checkdate($d[2], $d[3], $d[1]))) fail('Termiņš nav derīgs.');
        $due = $due === '' ? null : $due;
        if ($pid && !isMember($pid, $uid)) fail('Nav piekļuves.', 403);
        $as = ($pid && !empty($in['assignee']) && isMember($pid, (int)$in['assignee'])) ? (int)$in['assignee'] : null;
        if (!empty($in['id'])) {
            $t = one('SELECT * FROM tasks WHERE id=?', [(int)$in['id']]);
            if (!canTask($t, $uid)) fail('Nav tiesību.', 403);
            q('UPDATE tasks SET title=?,descr=?,due_date=?,prio=?,assignee_id=? WHERE id=?', [$title, $desc, $due, $prio, $t['project_id'] === null ? null : $as, $t['id']]);
        } else {
            q('INSERT INTO tasks(user_id,project_id,title,descr,due_date,prio,created_by,assignee_id) VALUES(?,?,?,?,?,?,?,?)',
                [$pid ? null : $uid, $pid, $title, $desc, $due, $prio, $uid, $as]);
        }
        out(['ok' => true]);

    case 'task_toggle':
        $t = one('SELECT * FROM tasks WHERE id=?', [(int)($in['id'] ?? 0)]);
        if (!canTask($t, $uid)) fail('Nav tiesību.', 403);
        q('UPDATE tasks SET done=? WHERE id=?', [empty($in['done']) ? 0 : 1, $t['id']]);
        out(['ok' => true]);

    case 'task_del':
        $t = one('SELECT * FROM tasks WHERE id=?', [(int)($in['id'] ?? 0)]);
        if (!canTask($t, $uid)) fail('Nav tiesību.', 403);
        q('DELETE FROM tasks WHERE id=?', [$t['id']]);
        out(['ok' => true]);

    case 'clear_done':
        $pid = !empty($in['pid']) ? (int)$in['pid'] : null;
        if ($pid) { if (!owns($pid, $uid)) fail('Nav tiesību.', 403); q('DELETE FROM tasks WHERE project_id=? AND done=1', [$pid]); }
        else q('DELETE FROM tasks WHERE user_id=? AND project_id IS NULL AND done=1', [$uid]);
        out(['ok' => true]);

    case 'project_add':
        $n = str('name', 60);
        if (mb_strlen($n) < 2 || mb_strlen($n) > 60) fail('Projekta nosaukumam jābūt 2 līdz 60 rakstzīmēm.');
        q('INSERT INTO projects(name,owner_id) VALUES(?,?)', [$n, $uid]);
        $id = $pdo->lastInsertId();
        q('INSERT INTO project_members VALUES(?,?)', [$id, $uid]);
        out(['id' => (string)$id]);

    case 'project_del':
        $pid = (int)($in['pid'] ?? 0);
        if (!owns($pid, $uid)) fail('Nav tiesību.', 403);
        q('DELETE FROM projects WHERE id=?', [$pid]);
        out(['ok' => true]);

    case 'invite':
        $pid = (int)($in['pid'] ?? 0); $e = strtolower(str('email', 120));
        if (!owns($pid, $uid)) fail('Nav tiesību.', 403);
        if (!filter_var($e, FILTER_VALIDATE_EMAIL)) fail('Ievadi derīgu e-pasta adresi.');
        $t = one('SELECT id FROM users WHERE email=?', [$e]);
        if (!$t) fail('Lietotājs ar šādu e-pastu nav reģistrēts.');
        if (isMember($pid, $t['id'])) fail('Šis lietotājs jau ir dalībnieks.');
        if (one("SELECT 1 FROM invites WHERE project_id=? AND to_id=? AND status='pending'", [$pid, $t['id']])) fail('Šis lietotājs jau ir uzaicināts.');
        q('INSERT INTO invites(project_id,to_id,from_id) VALUES(?,?,?)', [$pid, $t['id'], $uid]);
        out(['msg' => 'Uzaicinājums nosūtīts.']);

    case 'invite_reply':
        $i = one("SELECT * FROM invites WHERE id=? AND to_id=? AND status='pending'", [(int)($in['id'] ?? 0), $uid]);
        if (!$i) fail('Uzaicinājums nav atrasts.', 404);
        if (!empty($in['accept'])) q('INSERT IGNORE INTO project_members VALUES(?,?)', [$i['project_id'], $uid]);
        q('UPDATE invites SET status=? WHERE id=?', [empty($in['accept']) ? 'declined' : 'accepted', $i['id']]);
        out(['ok' => true]);

    case 'member_remove':
        $pid = (int)($in['pid'] ?? 0); $w = (int)($in['uid'] ?? 0);
        $p = one('SELECT owner_id FROM projects WHERE id=?', [$pid]);
        if (!$p || (int)$p['owner_id'] === $w) fail('Īpašnieku noņemt nevar.', 403);
        if (!((int)$p['owner_id'] === $uid || $w === $uid)) fail('Nav tiesību.', 403);
        q('DELETE FROM project_members WHERE project_id=? AND user_id=?', [$pid, $w]);
        q('UPDATE tasks SET assignee_id=NULL WHERE project_id=? AND assignee_id=?', [$pid, $w]);
        out(['ok' => true]);

    case 'rename':
        $n = str('n', 50);
        if (mb_strlen($n) < 2 || mb_strlen($n) > 50) fail('Vārdam jābūt 2 līdz 50 rakstzīmēm.');
        q('UPDATE users SET name=? WHERE id=?', [$n, $uid]);
        out(['ok' => true]);

    case 'password':
        $u = one('SELECT pass_hash FROM users WHERE id=?', [$uid]);
        if (!password_verify((string)($in['c'] ?? ''), $u['pass_hash'])) fail('Pašreizējā parole nav pareiza.');
        $p = (string)($in['p'] ?? '');
        if ($m = pwErr($p)) fail($m);
        q('UPDATE users SET pass_hash=? WHERE id=?', [password_hash($p, PASSWORD_DEFAULT), $uid]);
        out(['ok' => true]);
    }
    fail('Nezināma darbība.', 404);
} catch (Throwable $e) {
    fail('Servera kļūda.', 500);
}
