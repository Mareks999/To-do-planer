/* Pašreizējais konteksts: personīgie uzdevumi vai atvērtā projekta uzdevumi. Īstās tiesības pārbauda serveris. */
function ctx() {
  if (S.view === "me") return { items: S.me, members: [uid], owner: true, title: "Mani uzdevumi" };
  const p = S.proj.find((p) => p.id === S.view);
  if (!p) return { items: [], members: [], owner: false, title: "Ielādē…" };
  return { p, items: p.tasks || [], members: p.members || [], owner: p.owner === uid, title: p.name };
}
// Tikai interfeisam (pogu rādīšanai); serveris tāpat pārbauda katru darbību
const can = (c, t) => c.owner || t.by === uid || t.assignee === uid;
