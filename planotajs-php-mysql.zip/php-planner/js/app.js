/* app.js: lietotnes starts. Ja servera sesija ir derīga, lietotājs tiek pieslēgts automātiski. */
(async () => {
  try {
    await enter();
  } catch {
    $("#auth").hidden = false;
    setTab("in");
  }
})();
