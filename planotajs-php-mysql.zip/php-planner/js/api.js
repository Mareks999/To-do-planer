/* api.js: sazināšanās ar PHP serveri (api.php) un datu sinhronizācija. */
async function api(a, d = {}) {
  const r = await fetch("api.php?a=" + a, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: JSON.stringify(d),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || "Kļūda"), { status: r.status });
  return j;
}

// Ielādē visus lietotāja datus no servera un pārzīmē interfeisu
async function sync() {
  const s = await api("state");
  ACC = s.user;
  uid = s.user.id;
  Object.assign(names, s.names);
  Object.assign(S, { me: s.me, proj: s.proj, inv: s.inv });
  draw();
}
