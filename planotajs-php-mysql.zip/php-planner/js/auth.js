/* auth.js: reģistrācija, pieslēgšanās, izrakstīšanās un paroles maiņa. Paroli hashē un pārbauda serveris (PHP password_hash). */
let poll;

function setTab(t) {
  $("#fin").hidden = t !== "in";
  $("#fup").hidden = t !== "up";
  document
    .querySelectorAll("[data-a=at]")
    .forEach((b) => b.setAttribute("aria-pressed", b.dataset.id === t));
}

// Atver lietotni un reizi 5 sekundēs atjauno datus (lai redzētu citu lietotāju izmaiņas)
async function enter() {
  Object.assign(S, { view: "me", edit: null });
  await sync();
  $("#auth").hidden = true;
  $("#app").hidden = false;
  clearInterval(poll);
  poll = setInterval(() => sync().catch(() => {}), 5000);
}

async function out() {
  try {
    await api("logout");
  } catch {}
  clearInterval(poll);
  uid = ACC = null;
  $("#app").hidden = true;
  $("#auth").hidden = false;
  document.querySelectorAll("#auth input").forEach((i) => (i.value = ""));
  setTab("in");
}

$("#fup").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target,
    n = f.n.value.trim(),
    em = f.e.value.trim().toLowerCase(),
    p = f.p.value;
  const m =
    n.length < 2 || n.length > 50
      ? "Vārdam jābūt 2 līdz 50 rakstzīmēm."
      : !RE.test(em) || em.length > 120
        ? "Ievadi derīgu e-pasta adresi."
        : pwErr(p) || (p !== f.p2.value ? "Paroles nesakrīt." : "");
  er(f, m);
  if (m) return;
  try {
    await api("register", { n, e: em, p });
    f.reset();
    await enter();
  } catch (x) {
    er(f, x.message);
  }
});

$("#fin").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target,
    em = f.e.value.trim().toLowerCase(),
    p = f.p.value;
  if (!RE.test(em) || !p) return er(f, "Ievadi e-pastu un paroli.");
  try {
    await api("login", { e: em, p });
    er(f);
    f.reset();
    await enter();
  } catch (x) {
    er(f, x.message);
  }
});

$("#fpw").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target,
    p = f.p.value,
    m = pwErr(p) || (p !== f.p2.value ? "Paroles nesakrīt." : "");
  if (m) return er(f, m);
  try {
    await api("password", { c: f.c.value, p });
    f.reset();
    er(f);
    $("#pwd").close();
    msg("Parole nomainīta.");
  } catch (x) {
    er(f, x.message);
  }
});
