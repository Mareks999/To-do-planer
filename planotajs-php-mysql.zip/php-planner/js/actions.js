/* Lietotāja darbības: uzdevumi, projekti, uzaicinājumi un filtri. Katra izmaiņa iet caur serveri, pēc tam dati tiek pārlādēti. */
function reset() {
  S.edit = null;
  const f = $("#f");
  f.reset();
  er(f);
}
const pid = () => ctx().p?.id || null;

$("#f").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target,
    ti = f.ti.value.trim(),
    ds = f.ds.value.trim();
  const m = !ti
    ? "Ievadi uzdevuma nosaukumu."
    : ti.length > 100
      ? "Nosaukums drīkst būt līdz 100 rakstzīmēm."
      : ds.length > 500
        ? "Apraksts drīkst būt līdz 500 rakstzīmēm."
        : !P[f.pr.value]
          ? "Izvēlies prioritāti."
          : "";
  er(f, m);
  if (m) return;
  try {
    await api("task_save", {
      id: S.edit,
      pid: pid(),
      title: ti,
      desc: ds,
      due: f.du.value,
      prio: f.pr.value,
      assignee: f.as.value,
    });
    reset();
    $("#dlg").close();
    msg();
    await sync();
  } catch (x) {
    er(f, x.message);
  }
});
$("#dlg").addEventListener("close", () => {
  S.edit = null;
});
$("#np").addEventListener("submit", async (e) => {
  e.preventDefault();
  const n = e.target.n.value.trim();
  if (n.length < 2 || n.length > 60) return msg("Projekta nosaukumam jābūt 2 līdz 60 rakstzīmēm.");
  try {
    const r = await api("project_add", { name: n });
    e.target.reset();
    await sync();
    S.view = r.id;
    msg();
    draw();
  } catch (x) {
    msg(x.message);
  }
});
$("#fi").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target,
    o = $("#imsg");
  if (!ctx().p) return;
  try {
    const r = await api("invite", { pid: pid(), email: f.e.value.trim() });
    f.reset();
    o.textContent = r.msg;
  } catch (x) {
    o.textContent = x.message;
  }
});
document.addEventListener("click", async (e) => {
  const b = e.target.closest("[data-a]");
  if (!b || b.dataset.a === "tg") return;
  const a = b.dataset.a,
    id = b.dataset.id,
    c = ctx();
  try {
    if (a === "at") setTab(id);
    else if (a === "go") {
      S.view = id;
      reset();
      $("#imsg").textContent = "";
      msg();
      draw();
    } else if (a === "tab") {
      S.tab = id;
      draw();
    } else if (a === "nt") {
      reset();
      $("#dt").textContent = "Jauns uzdevums";
      $("#dlg").showModal();
    } else if (a === "cl") b.closest("dialog").close();
    else if (a === "pw") {
      const f = $("#fpw");
      f.reset();
      er(f);
      $("#pwd").showModal();
    } else if (a === "th") setTheme(id);
    else if (a === "en") {
      const f = $("#fnm");
      f.n.value = ACC.name;
      er(f);
      $("#nmd").showModal();
    } else if (a === "lo") out();
    else if (a === "edit") {
      const t = c.items.find((t) => t.id === id),
        f = $("#f");
      if (!t || !can(c, t)) return;
      S.edit = id;
      f.ti.value = t.title || "";
      f.ds.value = t.desc || "";
      f.du.value = t.due || "";
      f.pr.value = t.prio;
      f.as.value = t.assignee || "";
      er(f);
      $("#dt").textContent = "Labot uzdevumu";
      $("#dlg").showModal();
    } else if (a === "del") {
      if (confirm("Dzēst šo uzdevumu?")) await api("task_del", { id });
    } else if (a === "cc") {
      if (c.owner && confirm("Dzēst visus pabeigtos uzdevumus?")) await api("clear_done", { pid: pid() });
    } else if (a === "rm") {
      const w = id || uid;
      if (!c.p || !confirm(w === uid ? "Pamest šo projektu?" : "Noņemt dalībnieku no projekta?")) return;
      await api("member_remove", { pid: c.p.id, uid: w });
      if (w === uid) S.view = "me";
    } else if (a === "acc" || a === "rej") {
      await api("invite_reply", { id, accept: a === "acc" });
    } else if (a === "dp" && c.p && c.owner && confirm("Dzēst visu projektu un tā uzdevumus?")) {
      await api("project_del", { pid: c.p.id });
      S.view = "me";
    } else return;
    if (["del", "cc", "rm", "acc", "rej", "dp"].includes(a)) await sync();
  } catch {
    bad();
  }
});
document.addEventListener("change", async (e) => {
  const t = e.target;
  if (t.id === "so") {
    S.sort = t.value;
    draw();
  } else if (t.id === "fl") {
    S.fl = t.value;
    draw();
  } else if (t.id === "dz") {
    S.dz = t.value;
    draw();
  } else if (t.dataset.a === "tg") {
    try {
      await api("task_toggle", { id: t.dataset.id, done: t.checked });
      msg();
      await sync();
    } catch {
      bad();
    }
  }
});
document.addEventListener("input", (e) => {
  if (e.target.id === "sq") {
    S.q = e.target.value.trim();
    draw();
  }
});

// Izskata (Light/Dark) maiņa; izvēle tiek saglabāta pārlūkā
function setTheme(t) {
  try {
    localStorage.setItem("pl_theme", t);
  } catch {}
  document.documentElement.dataset.theme = t;
  draw();
}
// Vārda maiņa profilā
$("#fnm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target,
    n = f.n.value.trim();
  if (n.length < 2 || n.length > 50) return er(f, "Vārdam jābūt 2 līdz 50 rakstzīmēm.");
  try {
    await api("rename", { n });
    await sync();
    $("#nmd").close();
  } catch (x) {
    er(f, x.message);
  }
});
