# Plānotājs (To-Do Planner) — PHP + MySQL

Uzdevumu un projektu pārvaldības lietotne ar kontiem, kopīgiem projektiem un gaišo/tumšo režīmu.
Frontend: HTML, CSS, JavaScript. Backend: PHP (PDO) + MySQL.

## Palaišana (XAMPP / jebkurš PHP + MySQL)

1. Izveido datubāzi: importē `schema.sql` (phpMyAdmin → Import vai `mysql -u root < schema.sql`).
2. Pārbaudi pieslēguma datus failā `config.php`.
3. Ievieto mapi servera saknē (piem. `htdocs/planotajs`) vai palaid: `php -S localhost:8000`
4. Atver http://localhost:8000

## Drošība

- Paroles: `password_hash` / `password_verify` (serverī), nekad netiek sūtītas atpakaļ.
- Visi SQL pieprasījumi ir sagatavoti (PDO prepared statements), tātad aizsardzība pret SQL injekciju.
- Tiesības (īpašnieks, autors, piešķirtais dalībnieks) tiek pārbaudītas serverī katrā darbībā.
- Sesija: PHP sesija ar `HttpOnly` un `SameSite=Lax` sīkdatni; API pieņem tikai POST ar JSON.
- Izvade tiek ekranēta pārlūkā (XSS aizsardzība).
- Produkcijā papildus: HTTPS, atsevišķs MySQL lietotājs ar ierobežotām tiesībām, mēģinājumu ierobežošana pieslēgšanās formai.

## Faili

- `api.php` — visa servera loģika, `config.php` — DB pieslēgums, `schema.sql` — tabulas
- `index.html`, `css/` — interfeiss
- `js/api.js` — sazināšanās ar serveri; `auth.js`, `actions.js`, `render.js`, `state.js`, `helpers.js`, `app.js`
