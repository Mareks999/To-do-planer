const express = require('express');
const crypto = require('crypto');
const path = require('path');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

const PORT = process.env.PORT || 3000;
const SESSION_DAYS = 7;

const db = new Database(process.env.DB_PATH || path.join(__dirname, 'planner.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS members (
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('pending','accepted')),
  PRIMARY KEY (project_id, user_id)
);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  due_date TEXT,
  priority TEXT NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low','Medium','High')),
  done INTEGER NOT NULL DEFAULT 0,
  created_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  assignee_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_creator ON tasks(created_by);
`);

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '50kb' }));
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'"
  });
  next();
});
// CSRF aizsardzība: mainīgiem pieprasījumiem jābūt JSON (sīkdatnei ir arī SameSite=Lax)
app.use('/api', (req, res, next) => {
  if (!['GET', 'HEAD'].includes(req.method) && !req.is('application/json')) {
    return res.status(415).json({ error: 'Nepieciešams JSON pieprasījums.' });
  }
  next();
});

/* ---------- palīgfunkcijas ---------- */
class HttpError extends Error {
  constructor(status, message, field) { super(message); this.status = status; this.field = field; }
}
const wrap = fn => (req, res, next) => {
  try { fn(req, res, next); } catch (e) { next(e); }
};
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function cookie(req, name) {
  const m = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith(name + '='));
  return m ? decodeURIComponent(m.slice(name.length + 1)) : null;
}
function startSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const exp = Date.now() + SESSION_DAYS * 864e5;
  db.prepare('INSERT INTO sessions (token,user_id,expires_at) VALUES (?,?,?)').run(token, userId, exp);
  res.cookie('sid', token, {
    httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production',
    maxAge: SESSION_DAYS * 864e5, path: '/'
  });
}
const publicUser = u => ({ id: u.id, name: u.name, email: u.email });

/* ---------- autentifikācija ---------- */
const attempts = new Map(); // vienkāršs ierobežojums pieteikšanās mēģinājumiem
function tooMany(key) {
  const now = Date.now();
  const list = (attempts.get(key) || []).filter(t => now - t < 15 * 60e3);
  attempts.set(key, list);
  return list.length >= 10;
}

app.post('/api/register', wrap((req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (name.length < 2 || name.length > 60) throw new HttpError(400, 'Vārdam jābūt no 2 līdz 60 rakstzīmēm.', 'name');
  if (!EMAIL_RE.test(email) || email.length > 120) throw new HttpError(400, 'Ievadiet derīgu e-pasta adresi.', 'email');
  if (password.length < 8 || password.length > 72) throw new HttpError(400, 'Parolei jābūt no 8 līdz 72 rakstzīmēm.', 'password');
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) {
    throw new HttpError(409, 'Šāds e-pasts jau ir reģistrēts.', 'email');
  }
  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)').run(name, email, hash);
  startSession(res, info.lastInsertRowid);
  res.status(201).json({ user: { id: info.lastInsertRowid, name, email } });
}));

app.post('/api/login', wrap((req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const key = req.ip + '|' + email;
  if (tooMany(key)) throw new HttpError(429, 'Pārāk daudz mēģinājumu. Mēģiniet vēlāk.');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    attempts.get(key).push(Date.now());
    throw new HttpError(401, 'Nepareizs e-pasts vai parole.');
  }
  startSession(res, user.id);
  res.json({ user: publicUser(user) });
}));

app.post('/api/logout', wrap((req, res) => {
  const token = cookie(req, 'sid');
  if (token) db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
  res.clearCookie('sid', { path: '/' });
  res.json({ ok: true });
}));

function auth(req, res, next) {
  const token = cookie(req, 'sid');
  const row = token && db.prepare(
    'SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ? AND s.expires_at > ?'
  ).get(token, Date.now());
  if (!row) return res.status(401).json({ error: 'Nepieciešama pieslēgšanās.' });
  req.user = row;
  next();
}

app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
app.use('/api', auth); // viss zemāk ir aizsargāts

/* ---------- uzdevumu validācija un tiesības ---------- */
function parseTask(body, projectId) {
  const title = String(body.title || '').trim();
  const description = String(body.description || '').trim();
  const priority = body.priority || 'Medium';
  let due = body.due_date ? String(body.due_date) : null;
  if (title.length < 1 || title.length > 120) throw new HttpError(400, 'Nosaukumam jābūt no 1 līdz 120 rakstzīmēm.', 'title');
  if (description.length > 1000) throw new HttpError(400, 'Apraksts nedrīkst pārsniegt 1000 rakstzīmes.', 'description');
  if (!['Low', 'Medium', 'High'].includes(priority)) throw new HttpError(400, 'Nederīga prioritāte.', 'priority');
  if (due) {
    const d = new Date(due + 'T00:00:00Z');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(due) || isNaN(d) || d.toISOString().slice(0, 10) !== due) {
      throw new HttpError(400, 'Nederīgs termiņa datums.', 'due_date');
    }
  }
  let assignee = null;
  if (projectId && body.assignee_id) {
    assignee = Number(body.assignee_id);
    if (!isMember(projectId, assignee)) throw new HttpError(400, 'Izpildītājam jābūt projekta dalībniekam.', 'assignee_id');
  }
  return { title, description, priority, due_date: due, assignee_id: assignee };
}

const isMember = (pid, uid) =>
  !!db.prepare("SELECT 1 FROM members WHERE project_id=? AND user_id=? AND status='accepted'").get(pid, uid);
const getProject = id => db.prepare('SELECT * FROM projects WHERE id = ?').get(id);

function requireMember(pid, user) {
  const p = getProject(pid);
  // Neesošs projekts un svešs projekts izskatās vienādi (404), lai neizpaustu datus
  if (!p || !isMember(pid, user.id)) throw new HttpError(404, 'Projekts nav atrasts.');
  return p;
}

function decorate(t, user, project) {
  const isOwner = project && project.owner_id === user.id;
  const mine = t.created_by === user.id;
  const assigned = t.assignee_id === user.id;
  return {
    ...t, done: !!t.done,
    can_edit: project ? (isOwner || mine || assigned) : mine,
    can_delete: project ? (isOwner || mine) : mine
  };
}

const SORTS = {
  due: 'due_date IS NULL, due_date ASC, id DESC',
  priority: "CASE priority WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END, due_date IS NULL, due_date ASC",
  newest: 'id DESC'
};
function listClause(q) {
  const where = q.status === 'done' ? ' AND t.done = 1' : q.status === 'all' ? '' : ' AND t.done = 0';
  return { where, order: SORTS[q.sort] || SORTS.due };
}

/* ---------- personīgie uzdevumi ---------- */
app.get('/api/tasks', wrap((req, res) => {
  const { where, order } = listClause(req.query);
  const rows = db.prepare(
    `SELECT t.* FROM tasks t WHERE t.project_id IS NULL AND t.created_by = ?${where} ORDER BY ${order}`
  ).all(req.user.id);
  const counts = db.prepare(
    `SELECT SUM(done=0) AS active, SUM(done=1) AS done,
            SUM(done=0 AND due_date < date('now')) AS overdue
     FROM tasks WHERE project_id IS NULL AND created_by = ?`
  ).get(req.user.id);
  res.json({
    tasks: rows.map(t => decorate(t, req.user, null)),
    counts: { active: counts.active || 0, done: counts.done || 0, overdue: counts.overdue || 0 }
  });
}));

app.post('/api/tasks', wrap((req, res) => {
  const t = parseTask(req.body, null);
  const info = db.prepare(
    'INSERT INTO tasks (title,description,due_date,priority,created_by) VALUES (?,?,?,?,?)'
  ).run(t.title, t.description, t.due_date, t.priority, req.user.id);
  const row = db.prepare('SELECT * FROM tasks WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ task: decorate(row, req.user, null) });
}));

/* ---------- vispārīga uzdevuma maiņa/dzēšana ar tiesību pārbaudi ---------- */
function loadTask(req) {
  const t = db.prepare('SELECT * FROM tasks WHERE id = ?').get(Number(req.params.id));
  if (!t) throw new HttpError(404, 'Uzdevums nav atrasts.');
  const project = t.project_id ? getProject(t.project_id) : null;
  if (project ? !isMember(project.id, req.user.id) : t.created_by !== req.user.id) {
    throw new HttpError(404, 'Uzdevums nav atrasts.');
  }
  return { t, project };
}

app.put('/api/tasks/:id', wrap((req, res) => {
  const { t, project } = loadTask(req);
  if (!decorate(t, req.user, project).can_edit) throw new HttpError(403, 'Jums nav tiesību labot šo uzdevumu.');
  let next;
  if (Object.keys(req.body).length === 1 && 'done' in req.body) {
    next = { ...t, done: req.body.done ? 1 : 0 }; // ātrā statusa maiņa
  } else {
    const p = parseTask(req.body, project && project.id);
    // Piešķirt izpildītāju var tikai īpašnieks vai uzdevuma autors
    const canAssign = !project || project.owner_id === req.user.id || t.created_by === req.user.id;
    next = { ...t, ...p, assignee_id: canAssign ? p.assignee_id : t.assignee_id,
             done: 'done' in req.body ? (req.body.done ? 1 : 0) : t.done };
  }
  db.prepare(
    'UPDATE tasks SET title=?,description=?,due_date=?,priority=?,done=?,assignee_id=? WHERE id=?'
  ).run(next.title, next.description, next.due_date, next.priority, next.done, next.assignee_id, t.id);
  const row = db.prepare('SELECT * FROM tasks WHERE id = ?').get(t.id);
  res.json({ task: decorate(row, req.user, project) });
}));

app.delete('/api/tasks/:id', wrap((req, res) => {
  const { t, project } = loadTask(req);
  if (!decorate(t, req.user, project).can_delete) throw new HttpError(403, 'Jums nav tiesību dzēst šo uzdevumu.');
  db.prepare('DELETE FROM tasks WHERE id = ?').run(t.id);
  res.json({ ok: true });
}));

/* ---------- projekti ---------- */
app.get('/api/projects', wrap((req, res) => {
  const projects = db.prepare(
    `SELECT p.id, p.name, p.owner_id,
       (SELECT COUNT(*) FROM members m2 WHERE m2.project_id=p.id AND m2.status='accepted') AS members,
       (SELECT COUNT(*) FROM tasks t WHERE t.project_id=p.id AND t.done=0) AS active_tasks
     FROM projects p JOIN members m ON m.project_id=p.id
     WHERE m.user_id=? AND m.status='accepted' ORDER BY p.id DESC`
  ).all(req.user.id);
  const invites = db.prepare(
    `SELECT p.id AS project_id, p.name AS project_name, u.name AS owner_name
     FROM members m JOIN projects p ON p.id=m.project_id JOIN users u ON u.id=p.owner_id
     WHERE m.user_id=? AND m.status='pending' ORDER BY p.id DESC`
  ).all(req.user.id);
  res.json({ projects, invites });
}));

app.post('/api/projects', wrap((req, res) => {
  const name = String(req.body.name || '').trim();
  if (name.length < 2 || name.length > 80) throw new HttpError(400, 'Projekta nosaukumam jābūt no 2 līdz 80 rakstzīmēm.', 'name');
  const create = db.transaction(() => {
    const id = db.prepare('INSERT INTO projects (name,owner_id) VALUES (?,?)').run(name, req.user.id).lastInsertRowid;
    db.prepare("INSERT INTO members (project_id,user_id,status) VALUES (?,?, 'accepted')").run(id, req.user.id);
    return id;
  });
  res.status(201).json({ project: { id: create(), name, owner_id: req.user.id } });
}));

app.get('/api/projects/:id', wrap((req, res) => {
  const project = requireMember(Number(req.params.id), req.user);
  const isOwner = project.owner_id === req.user.id;
  const people = db.prepare(
    `SELECT u.id, u.name, u.email, m.status FROM members m JOIN users u ON u.id=m.user_id
     WHERE m.project_id=? ORDER BY m.status, u.name`
  ).all(project.id);
  // Gaidošos uzaicinājumus redz tikai īpašnieks
  const members = people.filter(p => p.status === 'accepted').map(p => ({ id: p.id, name: p.name, email: p.email }));
  const pending = isOwner ? people.filter(p => p.status === 'pending').map(p => ({ id: p.id, name: p.name, email: p.email })) : [];
  const { where, order } = listClause(req.query);
  const mineOnly = req.query.mine === '1' ? ' AND t.assignee_id = ' + Number(req.user.id) : '';
  const tasks = db.prepare(
    `SELECT t.*, a.name AS assignee_name, c.name AS creator_name
     FROM tasks t LEFT JOIN users a ON a.id=t.assignee_id JOIN users c ON c.id=t.created_by
     WHERE t.project_id=?${where}${mineOnly} ORDER BY ${order}`
  ).all(project.id);
  res.json({
    project: { id: project.id, name: project.name, owner_id: project.owner_id, is_owner: isOwner },
    members, pending,
    tasks: tasks.map(t => decorate(t, req.user, project))
  });
}));

app.delete('/api/projects/:id', wrap((req, res) => {
  const project = requireMember(Number(req.params.id), req.user);
  if (project.owner_id !== req.user.id) throw new HttpError(403, 'Projektu var dzēst tikai īpašnieks.');
  db.prepare('DELETE FROM projects WHERE id = ?').run(project.id);
  res.json({ ok: true });
}));

app.post('/api/projects/:id/invite', wrap((req, res) => {
  const project = requireMember(Number(req.params.id), req.user);
  if (project.owner_id !== req.user.id) throw new HttpError(403, 'Uzaicināt var tikai projekta īpašnieks.');
  const email = String(req.body.email || '').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Ievadiet derīgu e-pasta adresi.', 'email');
  const target = db.prepare('SELECT id, name FROM users WHERE email = ?').get(email);
  if (!target) throw new HttpError(404, 'Lietotājs ar šādu e-pastu nav reģistrēts.', 'email');
  const existing = db.prepare('SELECT status FROM members WHERE project_id=? AND user_id=?').get(project.id, target.id);
  if (existing) {
    throw new HttpError(409, existing.status === 'accepted'
      ? 'Šis lietotājs jau ir projekta dalībnieks.' : 'Uzaicinājums šim lietotājam jau ir nosūtīts.', 'email');
  }
  db.prepare("INSERT INTO members (project_id,user_id,status) VALUES (?,?, 'pending')").run(project.id, target.id);
  res.status(201).json({ invited: { id: target.id, name: target.name, email } });
}));

app.post('/api/projects/:id/invite/:action', wrap((req, res) => {
  const pid = Number(req.params.id);
  const { action } = req.params;
  if (!['accept', 'decline'].includes(action)) throw new HttpError(404, 'Nav atrasts.');
  const inv = db.prepare("SELECT 1 FROM members WHERE project_id=? AND user_id=? AND status='pending'").get(pid, req.user.id);
  if (!inv) throw new HttpError(404, 'Uzaicinājums nav atrasts.');
  if (action === 'accept') {
    db.prepare("UPDATE members SET status='accepted' WHERE project_id=? AND user_id=?").run(pid, req.user.id);
  } else {
    db.prepare('DELETE FROM members WHERE project_id=? AND user_id=?').run(pid, req.user.id);
  }
  res.json({ ok: true });
}));

app.delete('/api/projects/:id/members/:userId', wrap((req, res) => {
  const project = requireMember(Number(req.params.id), req.user);
  const uid = Number(req.params.userId);
  const self = uid === req.user.id;
  if (!self && project.owner_id !== req.user.id) throw new HttpError(403, 'Dalībnieku var noņemt tikai īpašnieks.');
  if (uid === project.owner_id) throw new HttpError(400, 'Īpašnieku nevar noņemt no projekta.');
  db.transaction(() => {
    db.prepare('DELETE FROM members WHERE project_id=? AND user_id=?').run(project.id, uid);
    db.prepare('UPDATE tasks SET assignee_id=NULL WHERE project_id=? AND assignee_id=?').run(project.id, uid);
  })();
  res.json({ ok: true });
}));

app.post('/api/projects/:id/tasks', wrap((req, res) => {
  const project = requireMember(Number(req.params.id), req.user);
  const t = parseTask(req.body, project.id);
  const info = db.prepare(
    'INSERT INTO tasks (title,description,due_date,priority,created_by,project_id,assignee_id) VALUES (?,?,?,?,?,?,?)'
  ).run(t.title, t.description, t.due_date, t.priority, req.user.id, project.id, t.assignee_id);
  const row = db.prepare('SELECT * FROM tasks WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ task: decorate(row, req.user, project) });
}));

/* ---------- statiskie faili un kļūdu apstrāde ---------- */
app.use('/api', (req, res) => res.status(404).json({ error: 'Nav atrasts.' }));
app.use(express.static(path.join(__dirname, 'public')));

app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, field: err.field });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Nederīgs JSON.' });
  console.error(err);
  res.status(500).json({ error: 'Servera kļūda.' });
});

setInterval(() => db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now()), 3600e3).unref();

app.listen(PORT, () => console.log(`To-Do Planner darbojas: http://localhost:${PORT}`));
