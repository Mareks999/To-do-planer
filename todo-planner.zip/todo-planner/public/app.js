'use strict';

const root = document.getElementById('app');
const dialog = document.getElementById('taskDialog');
const taskForm = document.getElementById('taskForm');
let me = null;
const state = {
  personal: { status: 'active', sort: 'due' },
  project: { status: 'active', sort: 'due', mine: false }
};

/* ---------- palīgfunkcijas ---------- */
// Elementu veidotājs: teksts vienmēr tiek ievietots kā textContent (aizsardzība pret XSS)
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(kid));
  }
  return el;
}

async function api(method, url, body) {
  const opts = { method, headers: {} };
  if (method !== 'GET') {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body || {});
  }
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && me && !url.includes('/login')) { me = null; renderAuth(); throw new Error('Sesija beigusies.'); }
  if (!res.ok) { const e = new Error(data.error || 'Neizdevās izpildīt darbību.'); e.field = data.field; throw e; }
  return data;
}

let toastTimer;
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}
const fail = e => toast(e.message);

const fmtDate = d => d ? d.split('-').reverse().join('.') : '';
const today = () => new Date().toLocaleDateString('sv');

function clearErrors(form) {
  form.querySelectorAll('.err').forEach(s => (s.textContent = ''));
  form.querySelectorAll('[aria-invalid]').forEach(i => i.removeAttribute('aria-invalid'));
}
function showError(form, e, fallbackEl) {
  const span = e.field && form.querySelector(`.err[data-for="${e.field}"]`);
  if (span) {
    span.textContent = e.message;
    const input = form.elements[e.field];
    if (input) { input.setAttribute('aria-invalid', 'true'); input.focus(); }
  } else if (fallbackEl) fallbackEl.textContent = e.message;
  else toast(e.message);
}

/* ---------- autentifikācija ---------- */
function renderAuth(mode = 'login') {
  const isReg = mode === 'register';
  const field = (label, name, type, extra = {}) =>
    h('label', {}, label,
      h('input', { name, type, required: true, autocomplete: extra.ac, minlength: extra.min }),
      extra.hint && h('span', { class: 'hint' }, extra.hint),
      h('span', { class: 'err', 'data-for': name }));
  const formErr = h('p', { class: 'err', role: 'alert' });
  const form = h('form', { novalidate: true },
    isReg && field('Vārds', 'name', 'text', { ac: 'name' }),
    field('E-pasts', 'email', 'email', { ac: 'email' }),
    field('Parole', 'password', 'password', { ac: isReg ? 'new-password' : 'current-password', hint: isReg ? 'Vismaz 8 rakstzīmes.' : null }),
    formErr,
    h('button', { class: 'primary', type: 'submit', style: 'width:100%' }, isReg ? 'Izveidot kontu' : 'Pieslēgties'));

  form.addEventListener('submit', async ev => {
    ev.preventDefault();
    clearErrors(form); formErr.textContent = '';
    const body = Object.fromEntries(new FormData(form));
    // klienta puses pārbaude (serveris validē vēlreiz)
    if (isReg && body.name.trim().length < 2) return showError(form, { field: 'name', message: 'Ievadiet vārdu (vismaz 2 rakstzīmes).' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(body.email.trim())) return showError(form, { field: 'email', message: 'Ievadiet derīgu e-pasta adresi.' });
    if (isReg && body.password.length < 8) return showError(form, { field: 'password', message: 'Parolei jābūt vismaz 8 rakstzīmēm.' });
    if (!body.password) return showError(form, { field: 'password', message: 'Ievadiet paroli.' });
    try {
      const data = await api('POST', isReg ? '/api/register' : '/api/login', body);
      me = data.user;
      location.hash = '#/';
      route();
    } catch (e) { showError(form, e, formErr); }
  });

  const tab = (m, label) => h('button', {
    type: 'button', role: 'tab', 'aria-selected': String(mode === m),
    onclick: () => renderAuth(m)
  }, label);

  root.replaceChildren(h('div', { class: 'auth' },
    h('div', { class: 'card' },
      h('div', { class: 'tabs', role: 'tablist' }, tab('login', 'Pieslēgties'), tab('register', 'Reģistrēties')),
      h('h1', {}, isReg ? 'Izveidot kontu' : 'Laipni lūdzam atpakaļ'),
      form)));
  form.querySelector('input').focus();
}

/* ---------- čaula ---------- */
function shell(active, ...content) {
  const link = (href, label, key, extra) =>
    h('a', { href, 'aria-current': active === key ? 'page' : null }, label, extra);
  const badge = h('span', { class: 'badge', hidden: true });
  root.replaceChildren(
    h('header', { class: 'topbar' }, h('div', { class: 'topbar-in' },
      h('span', { class: 'brand' }, 'Plānotājs'),
      h('nav', { class: 'nav' }, link('#/', 'Mani uzdevumi', 'home'), link('#/projects', 'Projekti', 'projects', badge)),
      h('span', { class: 'who' }, me.name),
      h('button', { class: 'small ghost', onclick: logout }, 'Iziet'))),
    h('main', {}, ...content));
  api('GET', '/api/projects').then(d => {
    if (d.invites.length) { badge.textContent = d.invites.length; badge.hidden = false; }
  }).catch(() => {});
}

async function logout() {
  await api('POST', '/api/logout').catch(() => {});
  me = null; location.hash = '#/'; renderAuth();
}

/* ---------- uzdevumu saraksts un dialogs ---------- */
function taskItem(t, { onChange, onEdit }) {
  const overdue = t.due_date && !t.done && t.due_date < today();
  const check = h('input', {
    type: 'checkbox', checked: t.done, disabled: !t.can_edit,
    'aria-label': (t.done ? 'Atzīmēt kā nepabeigtu: ' : 'Atzīmēt kā pabeigtu: ') + t.title,
    onchange: async e => {
      try { await api('PUT', `/api/tasks/${t.id}`, { done: e.target.checked }); onChange(); }
      catch (err) { e.target.checked = !e.target.checked; fail(err); }
    }
  });
  const actions = h('div', { class: 't-actions' },
    t.can_edit && h('button', { class: 'small', onclick: () => onEdit(t) }, 'Labot'),
    t.can_delete && h('button', {
      class: 'small danger',
      onclick: async () => {
        if (!confirm(`Dzēst uzdevumu “${t.title}”?`)) return;
        try { await api('DELETE', `/api/tasks/${t.id}`); toast('Uzdevums izdzēsts'); onChange(); } catch (e) { fail(e); }
      }
    }, 'Dzēst'));
  return h('li', { class: `task p-${t.priority}${t.done ? ' is-done' : ''}` },
    check,
    h('div', {},
      h('div', { class: 't-title' }, t.title),
      t.description && h('p', { class: 't-desc' }, t.description),
      h('div', { class: 'meta' },
        h('span', { class: `pri-${t.priority}` }, t.priority),
        t.due_date && h('span', { class: overdue ? 'overdue' : '' }, `Termiņš: ${fmtDate(t.due_date)}${overdue ? ' (nokavēts)' : ''}`),
        'assignee_name' in t && h('span', {}, t.assignee_name ? `Izpildītājs: ${t.assignee_name}` : 'Nav piešķirts'),
        t.creator_name && h('span', {}, `Izveidoja: ${t.creator_name}`))),
    actions);
}

function taskList(tasks, opts, emptyText) {
  if (!tasks.length) return h('div', { class: 'empty' }, emptyText);
  return h('ul', { class: 'tasks' }, tasks.map(t => taskItem(t, opts)));
}

// Uzdevuma dialogs: izveidei un labošanai; members → rāda izpildītāja izvēli
function openTaskDialog({ task, members, onSave }) {
  clearErrors(taskForm);
  document.getElementById('taskFormErr').textContent = '';
  document.getElementById('taskDialogTitle').textContent = task ? 'Labot uzdevumu' : 'Jauns uzdevums';
  const f = taskForm.elements;
  f.title.value = task ? task.title : '';
  f.description.value = task ? task.description : '';
  f.due_date.value = task && task.due_date ? task.due_date : '';
  f.priority.value = task ? task.priority : 'Medium';
  const wrap = document.getElementById('assigneeWrap');
  wrap.hidden = !members;
  if (members) {
    f.assignee_id.replaceChildren(h('option', { value: '' }, 'Nav piešķirts'),
      members.map(m => h('option', { value: m.id }, m.name)));
    f.assignee_id.value = task && task.assignee_id ? task.assignee_id : '';
  }
  taskForm.onsubmit = async ev => {
    ev.preventDefault();
    clearErrors(taskForm);
    const body = {
      title: f.title.value.trim(), description: f.description.value.trim(),
      due_date: f.due_date.value || null, priority: f.priority.value,
      assignee_id: members && f.assignee_id.value ? Number(f.assignee_id.value) : null
    };
    if (!body.title) return showError(taskForm, { field: 'title', message: 'Ievadiet uzdevuma nosaukumu.' });
    try { await onSave(body); dialog.close(); } catch (e) { showError(taskForm, e, document.getElementById('taskFormErr')); }
  };
  dialog.showModal();
  f.title.focus();
}
document.getElementById('taskCancel').addEventListener('click', () => dialog.close());

function filters(s, rerender, { withMine } = {}) {
  const seg = h('div', { class: 'seg', role: 'group', 'aria-label': 'Statuss' },
    [['active', 'Aktīvie'], ['done', 'Pabeigtie'], ['all', 'Visi']].map(([v, l]) =>
      h('button', { type: 'button', 'aria-pressed': String(s.status === v), onclick: () => { s.status = v; rerender(); } }, l)));
  const sort = h('select', { 'aria-label': 'Kārtot pēc', onchange: e => { s.sort = e.target.value; rerender(); } },
    [['due', 'Kārtot: termiņš'], ['priority', 'Kārtot: prioritāte'], ['newest', 'Kārtot: jaunākie']]
      .map(([v, l]) => h('option', { value: v, selected: s.sort === v }, l)));
  const mine = withMine && h('label', { style: 'margin:0;display:flex;gap:6px;align-items:center;font-weight:400' },
    h('input', { type: 'checkbox', style: 'width:auto;margin:0', checked: s.mine, onchange: e => { s.mine = e.target.checked; rerender(); } }),
    'Tikai man piešķirtie');
  return [seg, sort, mine];
}

/* ---------- dashboard ---------- */
async function viewDashboard() {
  const s = state.personal;
  const data = await api('GET', `/api/tasks?status=${s.status}&sort=${s.sort}`);
  const stat = (n, l, warn) => h('div', { class: 'stat' + (warn && n ? ' warn' : '') }, h('b', {}, n), h('span', {}, l));
  const refresh = () => route();
  const empty = { active: 'Nav aktīvu uzdevumu. Pievienojiet pirmo!', done: 'Vēl nav pabeigtu uzdevumu.', all: 'Uzdevumu vēl nav.' }[s.status];
  shell('home',
    h('h1', {}, `Sveiki, ${me.name.split(' ')[0]}!`),
    h('p', { class: 'sub' }, 'Jūsu personīgie uzdevumi.'),
    h('div', { class: 'stats' }, stat(data.counts.active, 'Aktīvie'), stat(data.counts.overdue, 'Nokavētie', true), stat(data.counts.done, 'Pabeigtie')),
    h('div', { class: 'toolbar' }, filters(s, refresh), h('span', { class: 'grow' }),
      h('button', { class: 'primary', onclick: () => openTaskDialog({ onSave: async b => { await api('POST', '/api/tasks', b); toast('Uzdevums pievienots'); refresh(); } }) }, 'Jauns uzdevums')),
    taskList(data.tasks, {
      onChange: refresh,
      onEdit: t => openTaskDialog({ task: t, onSave: async b => { await api('PUT', `/api/tasks/${t.id}`, b); toast('Izmaiņas saglabātas'); refresh(); } })
    }, empty));
}

/* ---------- projekti ---------- */
async function viewProjects() {
  const data = await api('GET', '/api/projects');
  const refresh = () => route();
  const err = h('span', { class: 'err', 'data-for': 'name' });
  const form = h('form', { class: 'inline-form', novalidate: true },
    h('input', { name: 'name', placeholder: 'Jauna projekta nosaukums', maxlength: 80, 'aria-label': 'Projekta nosaukums' }),
    h('button', { class: 'primary', type: 'submit' }, 'Izveidot projektu'), err);
  form.addEventListener('submit', async ev => {
    ev.preventDefault(); clearErrors(form);
    try {
      const { project } = await api('POST', '/api/projects', { name: form.elements.name.value });
      location.hash = `#/project/${project.id}`;
    } catch (e) { showError(form, e); }
  });
  const respond = (pid, action) => async () => {
    try { await api('POST', `/api/projects/${pid}/invite/${action}`); toast(action === 'accept' ? 'Uzaicinājums pieņemts' : 'Uzaicinājums noraidīts'); refresh(); }
    catch (e) { fail(e); }
  };
  shell('projects',
    h('h1', {}, 'Projekti'),
    h('p', { class: 'sub' }, 'Strādājiet pie uzdevumiem kopā ar citiem.'),
    form,
    data.invites.length > 0 && h('div', {},
      h('h2', {}, 'Uzaicinājumi'),
      h('ul', { class: 'list' }, data.invites.map(i => h('li', { class: 'item' },
        h('div', {}, h('strong', {}, i.project_name), h('small', {}, `Uzaicināja: ${i.owner_name}`)),
        h('div', { class: 't-actions' },
          h('button', { class: 'small primary', onclick: respond(i.project_id, 'accept') }, 'Pieņemt'),
          h('button', { class: 'small', onclick: respond(i.project_id, 'decline') }, 'Noraidīt')))))),
    h('h2', {}, 'Mani projekti'),
    data.projects.length
      ? h('ul', { class: 'list' }, data.projects.map(p => h('li', { class: 'item' },
          h('div', {}, h('a', { href: `#/project/${p.id}` }, p.name),
            h('small', {}, `${p.members} dalībn. · ${p.active_tasks} aktīvi uzdevumi${p.owner_id === me.id ? ' · jūs esat īpašnieks' : ''}`)))))
      : h('div', { class: 'empty' }, 'Jums vēl nav projektu. Izveidojiet pirmo augstāk.'));
}

async function viewProject(id) {
  const s = state.project;
  let data;
  try { data = await api('GET', `/api/projects/${id}?status=${s.status}&sort=${s.sort}&mine=${s.mine ? 1 : 0}`); }
  catch (e) { toast(e.message); location.hash = '#/projects'; return; }
  const { project, members, pending, tasks } = data;
  const refresh = () => route();

  const chip = (m, pend) => h('span', { class: 'chip' + (pend ? ' pending' : '') },
    m.name + (m.id === project.owner_id ? ' (īpašnieks)' : '') + (pend ? ' — gaida atbildi' : ''),
    project.is_owner && m.id !== project.owner_id && h('button', {
      'aria-label': `Noņemt ${m.name}`, title: 'Noņemt',
      onclick: async () => {
        if (!confirm(`Noņemt ${m.name} no projekta?`)) return;
        try { await api('DELETE', `/api/projects/${id}/members/${m.id}`); refresh(); } catch (e) { fail(e); }
      }
    }, '×'));

  let inviteForm = null;
  if (project.is_owner) {
    inviteForm = h('form', { class: 'inline-form', novalidate: true, style: 'margin-top:10px' },
      h('input', { name: 'email', type: 'email', placeholder: 'Uzaicināmā lietotāja e-pasts', 'aria-label': 'E-pasts', autocomplete: 'off' }),
      h('button', { type: 'submit' }, 'Uzaicināt'), h('span', { class: 'err', 'data-for': 'email' }));
    inviteForm.addEventListener('submit', async ev => {
      ev.preventDefault(); clearErrors(inviteForm);
      try { await api('POST', `/api/projects/${id}/invite`, { email: inviteForm.elements.email.value }); toast('Uzaicinājums nosūtīts'); refresh(); }
      catch (e) { showError(inviteForm, e); }
    });
  }

  const leaveBtn = project.is_owner
    ? h('button', { class: 'small danger', onclick: async () => {
        if (!confirm('Dzēst projektu un visus tā uzdevumus?')) return;
        try { await api('DELETE', `/api/projects/${id}`); location.hash = '#/projects'; } catch (e) { fail(e); }
      } }, 'Dzēst projektu')
    : h('button', { class: 'small', onclick: async () => {
        if (!confirm('Pamest šo projektu?')) return;
        try { await api('DELETE', `/api/projects/${id}/members/${me.id}`); location.hash = '#/projects'; } catch (e) { fail(e); }
      } }, 'Pamest projektu');

  shell('projects',
    h('a', { class: 'back', href: '#/projects' }, '‹ Visi projekti'),
    h('div', { class: 'proj-head' }, h('h1', {}, project.name), leaveBtn),
    h('h2', {}, 'Dalībnieki'),
    h('div', { class: 'chips' }, members.map(m => chip(m, false)), pending.map(m => chip(m, true))),
    inviteForm,
    h('h2', {}, 'Uzdevumi'),
    h('div', { class: 'toolbar' }, filters(s, refresh, { withMine: true }), h('span', { class: 'grow' }),
      h('button', { class: 'primary', onclick: () => openTaskDialog({ members, onSave: async b => { await api('POST', `/api/projects/${id}/tasks`, b); toast('Uzdevums pievienots'); refresh(); } }) }, 'Jauns uzdevums')),
    taskList(tasks, {
      onChange: refresh,
      onEdit: t => openTaskDialog({
        task: t, members: members,
        onSave: async b => { await api('PUT', `/api/tasks/${t.id}`, b); toast('Izmaiņas saglabātas'); refresh(); }
      })
    }, s.status === 'done' ? 'Vēl nav pabeigtu uzdevumu.' : 'Šajā skatā nav uzdevumu.'));
}

/* ---------- maršrutēšana ---------- */
async function route() {
  if (!me) return renderAuth();
  const hash = location.hash || '#/';
  try {
    const m = hash.match(/^#\/project\/(\d+)$/);
    if (m) await viewProject(Number(m[1]));
    else if (hash === '#/projects') await viewProjects();
    else await viewDashboard();
  } catch (e) { if (me) toast(e.message); }
}
window.addEventListener('hashchange', route);

(async function init() {
  try { me = (await api('GET', '/api/me')).user; } catch { me = null; }
  route();
})();
