# Plānotājs (To-Do Planner)

Node.js (Express) + SQLite. Interfeiss — vienas lapas JS lietotne (`public/`).

## Palaišana
```bash
npm install
npm start          # http://localhost:3000
```
Vides mainīgie (nav obligāti): `PORT`, `DB_PATH`, `NODE_ENV=production` (ieslēdz `Secure` sīkdatni, nepieciešams HTTPS).

## Drošība
- Paroles: bcrypt (12 raundi), datubāzē glabājas tikai hešs.
- Sesijas: nejaušs 256 bitu tokens DB, `HttpOnly` + `SameSite=Lax` sīkdatne, derīga 7 dienas.
- Visi SQL vaicājumi ir parametrizēti; ievaddati tiek validēti serverī; UI ievieto tekstu kā `textContent`.
- Piekļuves pārbaudes katrā maršrutā: personīgie uzdevumi — tikai autoram; projekta dati — tikai pieņemtiem dalībniekiem (svešiem 404).
- Pieteikšanās mēģinājumu ierobežojums (10 / 15 min uz e-pastu+IP).

## Tiesības projektā
| Darbība | Īpašnieks | Dalībnieks |
|---|---|---|
| Skatīt dalībniekus un uzdevumus | ✔ | ✔ |
| Izveidot uzdevumu | ✔ | ✔ |
| Labot / atzīmēt kā pabeigtu | visus | savus un sev piešķirtos |
| Dzēst uzdevumu | visus | savus |
| Piešķirt izpildītāju | ✔ | tikai savam uzdevumam |
| Uzaicināt / noņemt dalībniekus, dzēst projektu | ✔ | — (var pamest projektu) |

## API (īsi)
`POST /api/register|login|logout`, `GET /api/me`,
`GET|POST /api/tasks`, `PUT|DELETE /api/tasks/:id`,
`GET|POST /api/projects`, `GET|DELETE /api/projects/:id`,
`POST /api/projects/:id/invite`, `POST /api/projects/:id/invite/accept|decline`,
`DELETE /api/projects/:id/members/:userId`, `POST /api/projects/:id/tasks`.
